<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\Models\Shop;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;

class SetupController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    /**
     * Create install function
     *
     * @return 'Redirect URI'
     */
    public function install()
    {
        $app_url =  env('APP_URL', '');
        $shop = $_GET['shop'];
        $api_key = env('SHOPIFY_API_KEY', '');
        $scopes = env('SHOPIFY_APP_SCOPES', 'read_orders,write_orders,read_products,write_products,write_script_tags, read_themes,write_themes,read_product_listings,read_customers,write_customers,read_inventory');
        $redirect_uri = $app_url . "/token";
        // Build install/approval URL to redirect to
        $install_url = "https://" . $shop . "/admin/oauth/authorize?client_id=" . $api_key . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);
        return redirect($install_url);
        // Redirect
    }
    /**
     * Create token function that stores Shopify store token in database
     *
     * @return 'Token cretae response'
     */
    public function token()
    {
        // Set variables for our request
        $api_key = env('SHOPIFY_API_KEY', '');
        $shared_secret = env('SHOPIFY_SECRUT_KEY', '');
        $params = $_GET; // Retrieve all request parameters
        $hmac = $_GET['hmac']; // Retrieve HMAC request parameter
        $params = array_diff_key($params, array('hmac' => '')); // Remove hmac from params
        ksort($params); // Sort params lexographically
        $computed_hmac = hash_hmac('sha256', http_build_query($params), $shared_secret);
        // Use hmac data to check that the response is from Shopify or not
        if (hash_equals($hmac, $computed_hmac)) {

            // Set variables for our request
            $query = array(
                "client_id" => $api_key, // Your API key
                "client_secret" => $shared_secret, // Your app credentials (secret key)
                "code" => $params['code'] // Grab the access key from the URL
            );
            // Generate access token URL
            $access_token_url = "https://" . $params['shop'] . "/admin/oauth/access_token";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $access_token_url);
            curl_setopt($ch, CURLOPT_POST, count($query));
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($query));
            $result = curl_exec($ch);
            curl_close($ch);
            // Store the access token
            $result = json_decode($result, true);
            $access_token = $result['access_token'];
            // Show the access token (don't do this in production!)
            try {
                $shop = new Shop;
                $shop->shop_url = $params['shop'];
                $shop->access_token = $access_token;
                
                $user0 =  DB::table('freeShippingapp_')->where('shop_url', $params['shop'] )->get();
                if ($user0->count() == 0) {
                    if ($shop->save()) {
                        // var_dump($shop);
                        return redirect("https://" . $params['shop'] . "/admin/apps/nws-salecountdownbar");
                    } else {
                        echo 'Fail to store Access Token...';
                        return redirect( route('/') );
                    }
                }else{
                    return redirect("https://" . $params['shop'] . "/admin/apps/nws-salecountdownbar");
                }
                // if ($shop->save()) {
                //     // var_dump($shop);

                //     return redirect("https://" . $params['shop'] . "/admin/apps/nws-salecountdownbar");
                // } else {
                //     echo 'Fail to store Access Token...';
                //     return "";
                // }

            } catch (\Exception $e) {
                echo $e->getMessage();
            }
        } else {
            // Someone is trying to be shady!
            abort(401, 'Unauthorized action.');
            return "";
        }
    }

    /**
     * Create nwsapp function
     *
     * @return 'Redirect URI'
     */
    public function nwsapp()
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Security-Policy: frame-ancestors *');
        header('X-Frame-Options: ALLOWALL');

        $app_url =  env('APP_URL', '');
?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <!-- Google Fonts -->
	        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
            
            <link href='https://fonts.googleapis.com/css?family=Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette' rel='stylesheet' type='text/css'>
            <link href='https://fonts.googleapis.com/css?family=Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette' rel='stylesheet' type='text/css'>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="./assets/css/custom_app.css">
            <link rel="stylesheet" href="./assets/css/bootstrap-datetimepicker.css">
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.11.3/af-2.3.7/b-2.0.1/b-colvis-2.0.1/b-html5-2.0.1/b-print-2.0.1/cr-1.5.4/date-1.1.1/fc-4.0.0/fh-3.2.0/kt-2.6.4/r-2.2.9/rg-1.1.3/rr-1.2.8/sc-2.0.5/sb-1.2.2/sp-1.4.0/sl-1.3.3/datatables.min.css" />

            <!-- <link rel="stylesheet" href="./assets/lib/css/emoji.min.css"/> -->
            <link rel="stylesheet" href="https://onesignal.github.io/emoji-picker/lib/css/emoji.css" />
            <link rel="stylesheet" href="./assets/compiled/flipclock.css" />
            <!-- Styles -->
	        <link href="./assets/css/jquery_filer.css" rel="stylesheet">
	        <link href="./assets/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet">


            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/js/bootstrap.bundle.min.js"></script>
            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
            <script type="text/javascript" src="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.11.3/af-2.3.7/b-2.0.1/b-colvis-2.0.1/b-html5-2.0.1/b-print-2.0.1/cr-1.5.4/date-1.1.1/fc-4.0.0/fh-3.2.0/kt-2.6.4/r-2.2.9/rg-1.1.3/rr-1.2.8/sc-2.0.5/sb-1.2.2/sp-1.4.0/sl-1.3.3/datatables.min.js"></script>
            <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
            <script src="./assets/js/bootstrap-datetimepicker.js"></script>
            <script src="./assets/compiled/flipclock.js"></script>
            <script src="./assets/js/locales/bootstrap-datetimepicker.en.js"></script>
            <script src="./assets/js/jquery.filer.min.js"></script>

            <!-- <script src="./assets/lib/js/config.min.js"></script> -->
            <!-- <script src="./assets/lib/js/util.min.js"></script> -->
            <!-- <script src="./assets/lib/js/jquery.emojiarea.min.js"></script> -->
            <!-- <script src="./assets/lib/js/emoji-picker.min.js"></script> -->

            <script src="https://onesignal.github.io/emoji-picker/lib/js/config.js"></script>
            <script src="https://onesignal.github.io/emoji-picker/lib/js/util.js"></script>
            <script src="https://onesignal.github.io/emoji-picker/lib/js/jquery.emojiarea.js"></script>
            <script src="https://onesignal.github.io/emoji-picker/lib/js/emoji-picker.js"></script>


            <title>NWS Free Shipping Bar App</title>
        </head>
        <style></style>

        <body class="body" id="body">

            <?php
            $requests = $_GET;
            $hmac = $requests['hmac'];
            $requests = array_diff_key($requests, array('hmac' => '')); // Remove hmac from params
            ksort($requests); // Sort params lexographically
            $computed_hmac = hash_hmac('sha256', http_build_query($requests), env('SHOPIFY_SECRUT_KEY', ''));
            // Use hmac data to check that the response is from Shopify or not
            $serializeArray = serialize($requests);
            $requests = array_diff_key($requests, array('hmac' => ''));
            ksort($requests);
            $shop = $requests['shop'];
            $user0 =  DB::table('freeShippingapp_')->where('shop_url', $shop)->get();
            if ($user0->count() == 0) {
                $app_url =  env('APP_URL', '');
                $redirect_uri = $app_url . "/install?shop=" . $shop;
                return redirect($redirect_uri);
            } else {

                (hash_equals($hmac, $computed_hmac)) ? 'true' : abort(401, 'there is no access please reinstall app.');
                $chkProduct2 = DB::table('freeShippingapp_')->where('shop_url', $shop)->count();
                if ($chkProduct2 == 0) {
                    abort(401, 'there is no access please reinstall app.');
                }
                $chkProduct = DB::table('freeShippingapp_')->where('shop_url', $shop)->first();
                $result = (array) $chkProduct;
                $shop = $result['shop_url'];
                $token = $result['access_token'];
                $this->webhooks($token, $this->Get_host_shop($shop), env('APP_URL', ''), "2021-10");
            }


            $chkProduct = DB::table('freeShippingapp_')->where('shop_url', $shop)->first();
            $result = (array) $chkProduct;
            $shop = $result['shop_url'];
            $token = $result['access_token'];
            ///////////////////////////////////////////////     script tag
            $this->ScriptTags__callFunctions($token, $shop, "2021-10");
            ///////////////////////////////////////////////

            $GOT_Form_data_ = $result['data'];
            $GOT_Form_data_ARRAY = json_decode($GOT_Form_data_, true);

            $currency__ = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/shop.json", array(), 'GET');
            $currency__ = json_decode($currency__['response'], JSON_PRETTY_PRINT);


            // print_r($GOT_Form_data_ARRAY);

            $message_text1 = (isset($GOT_Form_data_ARRAY['message_text1'])) ? $GOT_Form_data_ARRAY['message_text1'] : "";
            $message_text2 = (isset($GOT_Form_data_ARRAY['message_text2'])) ? $GOT_Form_data_ARRAY['message_text2'] : "";
            $saleButton_label = (isset($GOT_Form_data_ARRAY['saleButton_label'])) ? $GOT_Form_data_ARRAY['saleButton_label'] : "";
            $saleButton_link = (isset($GOT_Form_data_ARRAY['saleButton_link'])) ? $GOT_Form_data_ARRAY['saleButton_link'] : "";
            $TimeZoneSelector_select = (isset($GOT_Form_data_ARRAY['TimeZoneSelector_select'])) ? $GOT_Form_data_ARRAY['TimeZoneSelector_select'] : "";
            $scheduling_sale_date = (isset($GOT_Form_data_ARRAY['scheduling_sale_date'])) ? $GOT_Form_data_ARRAY['scheduling_sale_date'] : "";
            $scheduling_sale_time = (isset($GOT_Form_data_ARRAY['scheduling_sale_time'])) ? $GOT_Form_data_ARRAY['scheduling_sale_time'] : "";
            $background_color = (isset($GOT_Form_data_ARRAY['background_color'])) ? $GOT_Form_data_ARRAY['background_color']  : "#000000";
            $background_opacity = (isset($GOT_Form_data_ARRAY['background_opacity'])) ? $GOT_Form_data_ARRAY['background_opacity']  : "1";
            $image_file_name = (isset($GOT_Form_data_ARRAY['image_file_name'])) ? $GOT_Form_data_ARRAY['image_file_name']  : "";
            $message_text_color = (isset($GOT_Form_data_ARRAY['message_text_color'])) ? $GOT_Form_data_ARRAY['message_text_color']  : "#FFFFFF";
            $button_text_color = (isset($GOT_Form_data_ARRAY['button_text_color'])) ? $GOT_Form_data_ARRAY['button_text_color']  : "#000000";
            $timer_text_color = (isset($GOT_Form_data_ARRAY['timer_text_color'])) ? $GOT_Form_data_ARRAY['timer_text_color']  : "#000000";
            $button_background_color = (isset($GOT_Form_data_ARRAY['button_background_color'])) ? $GOT_Form_data_ARRAY['button_background_color']  : "#FFFFFF";
            $timer_background_color = (isset($GOT_Form_data_ARRAY['timer_background_color'])) ? $GOT_Form_data_ARRAY['timer_background_color']  : "#FFFFFF";
            $timer_heading_color = (isset($GOT_Form_data_ARRAY['timer_heading_color'])) ? $GOT_Form_data_ARRAY['timer_heading_color']  : "#FFFFFF";
            $message_text_font_size_value = (isset($GOT_Form_data_ARRAY['message_text_font_size_value'])) ? $GOT_Form_data_ARRAY['message_text_font_size_value']  : "12";
            $message_text_font_unit_value = (isset($GOT_Form_data_ARRAY['message_text_font_unit_value'])) ? $GOT_Form_data_ARRAY['message_text_font_unit_value']  : "px";
            $timer_digit_font_size_value = (isset($GOT_Form_data_ARRAY['timer_digit_font_size_value'])) ? $GOT_Form_data_ARRAY['timer_digit_font_size_value']  : "18";
            $timer_digit_font_size_unit = (isset($GOT_Form_data_ARRAY['timer_digit_font_size_unit'])) ? $GOT_Form_data_ARRAY['timer_digit_font_size_unit']  : "px";
            $timer_text_heading_font_size_value = (isset($GOT_Form_data_ARRAY['timer_text_heading_font_size_value'])) ? $GOT_Form_data_ARRAY['timer_text_heading_font_size_value']  : "10";
            $timer_text_heading_font_size_unit = (isset($GOT_Form_data_ARRAY['timer_text_heading_font_size_unit'])) ? $GOT_Form_data_ARRAY['timer_text_heading_font_size_unit']  : "px";
            $button_text_font_size_value = (isset($GOT_Form_data_ARRAY['button_text_font_size_value'])) ? $GOT_Form_data_ARRAY['button_text_font_size_value']  : "10";
            $button_text_font_size_unit = (isset($GOT_Form_data_ARRAY['button_text_font_size_unit'])) ? $GOT_Form_data_ARRAY['button_text_font_size_unit']  : "px";
            $message_text_font_family_selector = (isset($GOT_Form_data_ARRAY['message_text_font_family_selector'])) ? $GOT_Form_data_ARRAY['message_text_font_family_selector']  : "inherit";
            $timer_digit_font_family_selector = (isset($GOT_Form_data_ARRAY['timer_digit_font_family_selector'])) ? $GOT_Form_data_ARRAY['timer_digit_font_family_selector']  : "inherit";
            $timer_heading_text_font_family_selector = (isset($GOT_Form_data_ARRAY['timer_heading_text_font_family_selector'])) ? $GOT_Form_data_ARRAY['timer_heading_text_font_family_selector']  : "inherit";
            $button_label_font_family_selector = (isset($GOT_Form_data_ARRAY['button_label_font_family_selector'])) ? $GOT_Form_data_ARRAY['button_label_font_family_selector']  : "inherit";



            // print_r($currency__['shop']['currency']);

            $Active_theme_ID = '';
            $Active_theme_NAME = '';

            $theme = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes.json", array(), 'GET');
            $theme = json_decode($theme['response'], JSON_PRETTY_PRINT);

            foreach ($theme as $theme_key => $theme_) {
                foreach ($theme_ as $theme_key_ => $theme_value) {
                    if ($theme_value['role'] == "main") {
                        $Active_theme_ID = $theme_value['id'];
                        $Active_theme_NAME = $theme_value['name'];
                    }
                }
            }

            DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('active_theme_id' => $Active_theme_ID)
            );

            $array = array(
                "asset" => array(
                    "key" => "layout/theme.liquid"
                )
            );
            $assets = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/" . $Active_theme_ID . "/assets.json", $array, 'GET');
            $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
            // print_r($assets['asset']['value']);
            // print_r( htmlentities( $assets['asset']['value'] ));
            // echo strpos( htmlentities( $assets['asset']['value'] ) , "{% include 'Shipping_bar_snippet' %}" );

            $theme_liquid_file_Data = $assets['asset']['value'];
            $snippet_file_name = "{% include 'saleCountDown_bar_snippet' %}";
            // $head_tag = '</head>';
            // $new_head_tag = $head_tag . $snippet_file_name;
            $head_tag = '</body>';
            $new_head_tag = $snippet_file_name . $head_tag;
            $new_theme_liquid_file_Data = str_replace($head_tag, $new_head_tag, $theme_liquid_file_Data);

            $OUTPUT_theme_liquid__ = "";
            if (strpos($assets['asset']['value'], $snippet_file_name) === false) {
                $array = array(
                    "asset" => array(
                        "key" => "layout/theme.liquid",
                        "value" => $new_theme_liquid_file_Data
                    )
                );
                $assets = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/" . $Active_theme_ID . "/assets.json", $array, 'PUT');
                $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
                // print_r($assets['asset']['value']);
                $OUTPUT_theme_liquid__ = $assets;
            }
            // print_r($OUTPUT_theme_liquid__);
            /////////////////////////////////////////////   Put  snippets --  Creating  countdown-bar.liquid in Store....
            $array = array(
                'asset' => array(
                    "key" => "snippets/saleCountDown_bar_snippet.liquid",
                    "value" => 
                    '<style> 
                        // .snowflake {
                        //     position: absolute;
                        //     width: 10px;
                        //     height: 10px;
                        //     background: linear-gradient(white, white);
                        //     border-radius: 50%;
                        //     filter: drop-shadow(0 0 10px white);
                        // } 
                    </style>' .
                    file_get_contents(getcwd() . "/saleCountDown_bar_snippet.txt") 
                )
            );
            $Put_selectedTheme_Assets = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/" . $Active_theme_ID . " /assets.json", $array, 'PUT');
            $Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
            // print_r($Put_selectedTheme_Assets);

            $this-> putCSS_resources_in_shopify_assets($token, $this->Get_host_shop($shop), $Active_theme_ID );
            $this-> putJS_resources_in_shopify_assets($token, $this->Get_host_shop($shop), $Active_theme_ID );
            $this-> putBootstrap_and_fonts_shopify_assets($token, $this->Get_host_shop($shop), $Active_theme_ID );
            $this-> putJS_Bootstrap_and_fonts_shopify_assets($token, $this->Get_host_shop($shop), $Active_theme_ID );
            

            ?>
            <section>
                <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">

                            <ul class="nav  bg-dark  mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link custom-btn " id="nav-Home-tab" data-bs-toggle="tab" data-bs-target="#nav-Home" type="button" role="tab" aria-controls="nav-Home" aria-selected="false">
                                        <img src="./assets/icons/Sales-Count-down-Timer.png" class="img-fluid img-thumbnail bg-dark" style="height:60px; padding: 0rem;border: 0px solid transparent;" alt="" id="Home-Window"></button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link custom-btn" id="nav-settings-tab" data-bs-toggle="tab" data-bs-target="#nav-settings" type="button" role="tab" aria-controls="nav-settings" aria-selected="false">Settings</button>
                                </li>
                                <li class="nav-item nav-item_helpguides" role="presentation">
                                    <button class="nav-link custom-btn" id="nav-helpguides-tab" data-bs-toggle="tab" data-bs-target="#nav-helpguides" type="button" role="tab" aria-controls="nav-helpguides" aria-selected="false">Helpguides</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link custom-btn" id="nav-subscriptions_pricing-tab" data-bs-toggle="modal" data-bs-target="#pricing_plan_Modal" type="button" role="tab" aria-controls="nav-subscriptions_pricing" aria-selected="false">Subscriptions & Pricing page</button>
                                </li>
                            </ul>
                            <span><img src="./assets/icons/external-link-alt-solid.png" class="img-fluid img-thumbnail  bg-dark" style="height:34px; padding: 0rem;border: 0px solid transparent;" alt="" id="redirect-to-newWindow"></span>
                        </div>
                    </div>
                </nav>

                <section class="app_body_" id="app_body_">

                    <div class="tab-content" id="pills-tabContent">
                        <!-- // ---------------------------------------------------------------------------------------------------------- -->
                        <div class="tab-pane fade" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings-tab">
                            <!-- //     Settings   tags  -->
                            <div class="settings_tab_container container">
                                // Settings

                            </div>
                        </div>
                        <!-- // ---------------------------------------------------------------------------------------------------------- -->
                        <div class="tab-pane fade" id="nav-helpguides" role="tabpanel" aria-labelledby="nav-helpguides-tab">
                            <div class="helpguides_tab_container container">
                                // Helplines

                            </div>
                        </div>
                        <div class="tab-pane fade active show" id="nav-Home" role="tabpanel" aria-labelledby="nav-Home-tab">
                            <div class="Home_tab_container container">

                                <div class="card content_card__" id="content_card__">
                                    <h5 class="card-header content_card__header">Content
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-up-square content_card__header_close_icon_class" viewBox="0 0 16 16">
                                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                                            <path d="M3.544 10.705A.5.5 0 0 0 4 11h8a.5.5 0 0 0 .374-.832l-4-4.5a.5.5 0 0 0-.748 0l-4 4.5a.5.5 0 0 0-.082.537z" />
                                        </svg>
                                    </h5>
                                    <div class="card-body content_card__body" value='0'>
                                        <section class="container content-free-shipping" id="content-free-shipping_id">

                                            <div class="row">
                                                <!-- <div class="col-md-12">
                                                    <h6>Message
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-chat-square-text" viewBox="0 0 20 20">
                                                            <path d="M14 1a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1h-2.5a2 2 0 0 0-1.6.8L8 14.333 6.1 11.8a2 2 0 0 0-1.6-.8H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2.5a1 1 0 0 1 .8.4l1.9 2.533a1 1 0 0 0 1.6 0l1.9-2.533a1 1 0 0 1 .8-.4H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                                                            <path d="M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6zm0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
                                                        </svg>
                                                    </h6>
                                                </div> -->
                                                <div class="col-sm-12 col-md-6">
                                                    <h6>Message before timer
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-left-text" viewBox="0 0 16 16">
                                                            <path d="M14 1a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4.414A2 2 0 0 0 3 11.586l-2 2V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12.793a.5.5 0 0 0 .854.353l2.853-2.853A1 1 0 0 1 4.414 12H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                                                            <path d="M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6zm0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
                                                        </svg>
                                                    </h6>
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" data-emojiable="true" class="form-control form-control-sm content_message_text content_message_text1" id="content_message_text1_id" placeholder="Annual Sale ends in" <?php echo ($message_text1 != "") ? 'value="' . $message_text1 . '"' : 'value="Annual Sale ends in"'; ?>>
                                                        <label for="content_message_text_id">Message Text First Half</label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-6">
                                                    <h6>Message after timer
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-right-text" viewBox="0 0 16 16">
                                                            <path d="M2 1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h9.586a2 2 0 0 1 1.414.586l2 2V2a1 1 0 0 0-1-1H2zm12-1a2 2 0 0 1 2 2v12.793a.5.5 0 0 1-.854.353l-2.853-2.853a1 1 0 0 0-.707-.293H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12z"/>
                                                            <path d="M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6zm0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
                                                        </svg>
                                                    </h6>
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" data-emojiable="true" class="form-control form-control-sm content_message_text content_message_text2" id="content_message_text2_id" placeholder="30% off for all orders" <?php echo ($message_text2 != "") ? 'value="' . $message_text2 . '"' : 'value="30% off for all orders"'; ?>>
                                                        <label for="content_message_text_id">Message Text Second Half</label>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h6>Sale Button label
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fonts" viewBox="0 0 16 16">
                                                            <path d="M12.258 3h-8.51l-.083 2.46h.479c.26-1.544.758-1.783 2.693-1.845l.424-.013v7.827c0 .663-.144.82-1.3.923v.52h4.082v-.52c-1.162-.103-1.306-.26-1.306-.923V3.602l.431.013c1.934.062 2.434.301 2.693 1.846h.479L12.258 3z"/>
                                                        </svg>
                                                    </h6>
                                                </div>
                                                <div class="col-sm-12 col-md-6">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" data-emojiable="true" class="form-control form-control-sm content_message_text saleButton_label" id="saleButton_label_id" placeholder="Hot Sale" <?php echo ($saleButton_label != "") ? 'value="' . $saleButton_label . '"' : 'value="Hot Sale!"'; ?>>
                                                        <label for="saleButton_label_id">Sale Button Label</label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-6">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" class="form-control form-control-sm content_message_text saleButton_link" id="saleButton_link_id" placeholder="https://yourshop_salelink.com" <?php echo ($saleButton_link != "") ? 'value="' . $saleButton_link . '"' : 'value="https://yourshop_salelink.com"'; ?>>
                                                        <label for="saleButton_link_id">Sale Button Link</label>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h6>Timer
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-stopwatch" viewBox="0 0 16 16">
                                                        <path d="M8.5 5.6a.5.5 0 1 0-1 0v2.9h-3a.5.5 0 0 0 0 1H8a.5.5 0 0 0 .5-.5V5.6z"/>
                                                        <path d="M6.5 1A.5.5 0 0 1 7 .5h2a.5.5 0 0 1 0 1v.57c1.36.196 2.594.78 3.584 1.64a.715.715 0 0 1 .012-.013l.354-.354-.354-.353a.5.5 0 0 1 .707-.708l1.414 1.415a.5.5 0 1 1-.707.707l-.353-.354-.354.354a.512.512 0 0 1-.013.012A7 7 0 1 1 7 2.071V1.5a.5.5 0 0 1-.5-.5zM8 3a6 6 0 1 0 .001 12A6 6 0 0 0 8 3z"/>
                                                    </svg>
                                                    </h6>
                                                </div>
                                                <div class="col-sm-12 col-md-12 col-lg-4" id="TimeZoneSelector-select_div">
                                                    <div class="form-floating mb-3">
                                                        <select class="form-select border-0 bg-light TimeZoneSelector-select" id="TimeZoneSelector-select-id" name="TimeZoneSelector_select">
                                                            <option selected>Select your time Zone</option>
                                                        </select>
                                                        <label for="TimeZoneSelector-select-id" class="form-label">Selected TimeZone:</label>
                                                    </div>
                                                    <p class="js-TimeUtc" id="js-TimeUtc"></p>
                                                </div>

                                                <div class="col-sm-12 col-md-6 col-lg-4">
                                                    <div class="form-floating mb-3">
                                                        <input type="date" class="form-control border-secondary border-0 bg-light" <?php echo ($scheduling_sale_date != "") ? 'value="' . $scheduling_sale_date . '"' : 'value=""'; ?> id="scheduling_sale_date" name="scheduling_sale_date">
                                                        <label for="scheduling_sale_date">Scheduling date:</label>
                                                        <div class="alert alert-danger" id="alert_forDateExpire" role="alert">Sale Expire!</div>

                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-6 col-lg-4">
                                                    <div class="form-floating mb-3">
                                                        <input type="time" class="form-control border-secondary border-0 bg-light" <?php echo ($scheduling_sale_time != "") ? 'value="' . $scheduling_sale_time . '"' : 'value=""'; ?> id="scheduling_sale_time" name="scheduling_sale_time">
                                                        <label for="scheduling_sale_time">Scheduling time:</label>
                                                    </div>
                                                </div>
                                                <!-- <div class="col-sm-12">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" class="form-control form-control-sm content_message_timepicker" value="" placeholder="Pick Date-time" id="content_message_timepicker_id" >
                                                        <label for="content_message_timepicker_id">Pick Date-Time</label>
                                                    </div>
                                                </div> -->
                                            </div>




                                        </section>
                                    </div>
                                </div>
                                <!-- ///////////////////////////////////////////////////////////////////////////////// -->


                                <div class="card background_card__" id="background_card__" style="margin-top:10px;">
                                    <h5 class="card-header background_card__header">Background
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-up-square background_card__header_close_icon_class" viewBox="0 0 16 16">
                                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                                            <path d="M3.544 10.705A.5.5 0 0 0 4 11h8a.5.5 0 0 0 .374-.832l-4-4.5a.5.5 0 0 0-.748 0l-4 4.5a.5.5 0 0 0-.082.537z" />
                                        </svg>
                                    </h5>
                                    <div class="card-body background_card__body" value='1'>
                                        <section class="container background-free-shipping" id="background-free-shipping_id">

                                            <div class="row">
                                                <!-- <div class="col-md-12">
                                                    <h6>Color
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                        </svg>  
                                                    </h6>
                                                </div> -->
                                                
                                                <div class="col-sm-12 col-md-6">
                                                    <h6>Color
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                        </svg>  
                                                    </h6>
                                                    <div class="form-floating mb-3">
                                                        <input type="color" class="form-control form-control-color background_colorpicked" id="background_colorpicked_id" name="background_colorpicked" value="<?php echo $background_color; ?>" title="Choose your color">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-6">
                                                    <h6>Opacity
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                        </svg>  
                                                    </h6>
                                                    <div class="form-floating mb-3">
                                                        <label id="background_step_selector_id" for="customRange2" class="form-label">The range is from 0 to 1, 0 = transparent and 1 = solid</label>
                                                        <input type="range" class="form-range background_step_selector" oninput="background_Opacity_Onchange_function(this.value)" min="0" max="1" step="0.01" value="<?php echo $background_opacity; ?>" name="background_step_selector"  id="background_step_selector_id">
                                                    </div>
                                                </div>
                                                
                                                <div class="col-sm-12"></div>

                                                <div class="col-sm-12 image_box">
                                                    <h6>Image
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-image" viewBox="0 0 16 16">
                                                            <path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                                                            <path d="M1.5 2A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13zm13 1a.5.5 0 0 1 .5.5v6l-3.775-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12v.54A.505.505 0 0 1 1 12.5v-9a.5.5 0 0 1 .5-.5h13z"/>
                                                        </svg>
                                                        <span>&ensp;<?php echo ($image_file_name != "") ? "( ". $image_file_name . " )" : ""; /* halloween02.png*/ ?></span>
                                                    </h6>
                                                    <div id="content">
                                                        <!-- Example 2 -->
                                                        <input type="hidden" name="filer_input_name" id="filer_input_name" value="<?php echo $image_file_name; /* halloween02.png*/ ?>">
                                                        <input type="file" name="files[]"  accept=".png,.jpg,.jpeg"  id="filer_input"   multiple="multiple"> 
                                                        <!-- end of Example 2 -->
                                                    </div>
                                                </div>
                                        
                                            </div>
                                            
                                        </section>
                                    </div>
                                </div>

                                <div class="card style_card__" id="style_card__">
                                    <h5 class="card-header style_card__header">Style Configuration
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-up-square style_card__header_close_icon_class" viewBox="0 0 16 16">
                                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                                            <path d="M3.544 10.705A.5.5 0 0 0 4 11h8a.5.5 0 0 0 .374-.832l-4-4.5a.5.5 0 0 0-.748 0l-4 4.5a.5.5 0 0 0-.082.537z" />
                                        </svg>
                                    </h5>
                                    <div class="card-body style_card__body" value='1'>
                                        <section class="container style-free-shipping" id="style-free-shipping_id">

                                            <div class="accordion style__config_accordion" id="style__config_accordion_id">
                                                <div class="accordion-item">
                                                    <h2 class="accordion-header" id="style_color_config_heading_id">
                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#style_color_config_collapse_id" aria-expanded="true" aria-controls="style_color_config_collapse_id">
                                                        Color&emsp;
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                        </svg>  
                                                    </button>
                                                    </h2>
                                                    <div id="style_color_config_collapse_id" class="accordion-collapse collapse show" aria-labelledby="style_color_config_heading_id" data-bs-parent="#style__config_accordion_id">
                                                        <div class="accordion-body">
                                                            <div class="row color__style">
                                                                <div class="col-sm-12 col-md-4 col-xl-auto">
                                                                    <h6 class="style___h6">Message Text Color
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                                        </svg>  
                                                                    </h6>
                                                                    <div class="form-floating mb-3">
                                                                        <input type="color" class="form-control form-control-color colorpicked_ message_text_colorpicked" id="message_text_colorpicked_id" name="message_text_colorpicked" value="<?php echo $message_text_color; ?>" title="Choose your color">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto">
                                                                    <h6 class="style___h6">Button Text Color
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16" >
                                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                                        </svg>  
                                                                    </h6>
                                                                    <div class="form-floating mb-3">
                                                                        <input type="color" class="form-control form-control-color colorpicked_ button_text_colorpicked" id="button_text_colorpicked_id" name="button_text_colorpicked" value="<?php echo $button_text_color; ?>" title="Button Text Color">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto">
                                                                    <h6 class="style___h6">Timer Heading Color
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                                        </svg>  
                                                                    </h6>
                                                                    <div class="form-floating mb-3">
                                                                        <input type="color" class="form-control form-control-color colorpicked_ timer_heading_colorpicked" id="timer_heading_colorpicked_id" name="timer_heading_colorpicked" value="<?php echo $timer_heading_color; ?>" title="Button Text Color">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto">
                                                                    <h6 class="style___h6">Timer Digit Color
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                                        </svg>  
                                                                    </h6>
                                                                    <div class="form-floating mb-3">
                                                                        <input type="color" class="form-control form-control-color colorpicked_ timer_text_colorpicked" id="timer_text_colorpicked_id" name="timer_text_colorpicked" value="<?php echo $timer_text_color; ?>" title="Button Text Color">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto">
                                                                    <h6 class="style___h6">Button Background Color
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                                        </svg>  
                                                                    </h6>
                                                                    <div class="form-floating mb-3">
                                                                        <input type="color" class="form-control form-control-color colorpicked_ button_background_colorpicked" id="button_background_colorpicked_id" name="button_background_colorpicked_id" value="<?php echo $button_background_color; ?>" title="Choose your color">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto">
                                                                    <h6 class="style___h6">Timer Background Color
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paint-bucket" viewBox="0 0 16 16">
                                                                            <path d="M6.192 2.78c-.458-.677-.927-1.248-1.35-1.643a2.972 2.972 0 0 0-.71-.515c-.217-.104-.56-.205-.882-.02-.367.213-.427.63-.43.896-.003.304.064.664.173 1.044.196.687.556 1.528 1.035 2.402L.752 8.22c-.277.277-.269.656-.218.918.055.283.187.593.36.903.348.627.92 1.361 1.626 2.068.707.707 1.441 1.278 2.068 1.626.31.173.62.305.903.36.262.05.64.059.918-.218l5.615-5.615c.118.257.092.512.05.939-.03.292-.068.665-.073 1.176v.123h.003a1 1 0 0 0 1.993 0H14v-.057a1.01 1.01 0 0 0-.004-.117c-.055-1.25-.7-2.738-1.86-3.494a4.322 4.322 0 0 0-.211-.434c-.349-.626-.92-1.36-1.627-2.067-.707-.707-1.441-1.279-2.068-1.627-.31-.172-.62-.304-.903-.36-.262-.05-.64-.058-.918.219l-.217.216zM4.16 1.867c.381.356.844.922 1.311 1.632l-.704.705c-.382-.727-.66-1.402-.813-1.938a3.283 3.283 0 0 1-.131-.673c.091.061.204.15.337.274zm.394 3.965c.54.852 1.107 1.567 1.607 2.033a.5.5 0 1 0 .682-.732c-.453-.422-1.017-1.136-1.564-2.027l1.088-1.088c.054.12.115.243.183.365.349.627.92 1.361 1.627 2.068.706.707 1.44 1.278 2.068 1.626.122.068.244.13.365.183l-4.861 4.862a.571.571 0 0 1-.068-.01c-.137-.027-.342-.104-.608-.252-.524-.292-1.186-.8-1.846-1.46-.66-.66-1.168-1.32-1.46-1.846-.147-.265-.225-.47-.251-.607a.573.573 0 0 1-.01-.068l3.048-3.047zm2.87-1.935a2.44 2.44 0 0 1-.241-.561c.135.033.324.11.562.241.524.292 1.186.8 1.846 1.46.45.45.83.901 1.118 1.31a3.497 3.497 0 0 0-1.066.091 11.27 11.27 0 0 1-.76-.694c-.66-.66-1.167-1.322-1.458-1.847z"/>
                                                                        </svg>  
                                                                    </h6>
                                                                    <div class="form-floating mb-3">
                                                                        <input type="color" class="form-control form-control-color colorpicked_ timer_background_colorpicked" id="timer_background_colorpicked_id" name="timer_background_colorpicked_id" value="<?php echo $timer_background_color; ?>" title="Choose your color">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-item">
                                                    <h2 class="accordion-header" id="font_size_config_heading_id">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#font_size_config_collapse_id" aria-expanded="false" aria-controls="font_size_config_collapse_id">
                                                        Font-size&emsp;
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fonts" viewBox="0 0 16 16">
                                                            <path d="M12.258 3h-8.51l-.083 2.46h.479c.26-1.544.758-1.783 2.693-1.845l.424-.013v7.827c0 .663-.144.82-1.3.923v.52h4.082v-.52c-1.162-.103-1.306-.26-1.306-.923V3.602l.431.013c1.934.062 2.434.301 2.693 1.846h.479L12.258 3z"/>
                                                        </svg>
                                                    </button>
                                                    </h2>
                                                    <div id="font_size_config_collapse_id" class="accordion-collapse collapse" aria-labelledby="font_size_config_heading_id" data-bs-parent="#style__config_accordion_id">
                                                        <div class="accordion-body">
                                                            <div class="row font__style">
                                                                <div class="col-sm-12 col-md-4 col-xl-auto message_text_font_size_div">
                                                                    <h6 class="style___h6">Message Text Font-size
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fonts" viewBox="0 0 16 16">
                                                                            <path d="M12.258 3h-8.51l-.083 2.46h.479c.26-1.544.758-1.783 2.693-1.845l.424-.013v7.827c0 .663-.144.82-1.3.923v.52h4.082v-.52c-1.162-.103-1.306-.26-1.306-.923V3.602l.431.013c1.934.062 2.434.301 2.693 1.846h.479L12.258 3z"/>
                                                                        </svg>
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <input type="number" min="0" max="100" value="<?php echo $message_text_font_size_value; ?>" class="form-control message_text_font_size_value" name="message_text_font_size_value" id="message_text_font_size_value_id" aria-label="Sizing example input" aria-describedby="inputGroup-text_font-sizing-sm_id">
                                                                        <span class="input-group-text" id="inputGroup-text_font-sizing-sm_id" style="padding:0px;" title="range is from 0 to 100">
                                                                            <select class="form-select form-select-sm message_text_font_size_unit" aria-label=".form-select-sm example" style="min-height: -webkit-fill-available;" id="message_text_font_size_unit_id" name="message_text_font_size_unit">
                                                                                <option selected value="<?php echo $message_text_font_unit_value; ?>">px</option>
                                                                                <!-- <option value="rem">rem</option>
                                                                                <option value="em">em</option>
                                                                                <option value="in">in</option> -->
                                                                            </select>
                                                                        </span>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto timer_digit_font_size_div">
                                                                    <h6 class="style___h6">Timer Digit Font-size
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fonts" viewBox="0 0 16 16">
                                                                            <path d="M12.258 3h-8.51l-.083 2.46h.479c.26-1.544.758-1.783 2.693-1.845l.424-.013v7.827c0 .663-.144.82-1.3.923v.52h4.082v-.52c-1.162-.103-1.306-.26-1.306-.923V3.602l.431.013c1.934.062 2.434.301 2.693 1.846h.479L12.258 3z"/>
                                                                        </svg>
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <input type="number" min="0" max="100" value="<?php echo $timer_digit_font_size_value; ?>" class="form-control timer_digit_font_size_value" name="timer_digit_font_size_value" id="timer_digit_font_size_value_id" aria-label="Sizing example input" aria-describedby="inputGroup-timer_digit_font-sizing-sm_id">
                                                                        <span class="input-group-text" id="inputGroup-timer_digit_font-sizing-sm_id" style="padding:0px;" title="range is from 0 to 100">
                                                                            <select class="form-select form-select-sm timer_digit_font_size_unit" aria-label=".form-select-sm example" style="min-height: -webkit-fill-available;" id="timer_digit_font_size_unit_id" name="timer_digit_font_size_unit">
                                                                                <option selected value="<?php echo $timer_digit_font_size_unit; ?>">px</option>
                                                                                <!-- <option value="rem">rem</option>
                                                                                <option value="em">em</option>
                                                                                <option value="in">in</option> -->
                                                                            </select>
                                                                        </span>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto timer_text_heading_font_size_div">
                                                                    <h6 class="style___h6">Timer Heading Font-size
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fonts" viewBox="0 0 16 16">
                                                                            <path d="M12.258 3h-8.51l-.083 2.46h.479c.26-1.544.758-1.783 2.693-1.845l.424-.013v7.827c0 .663-.144.82-1.3.923v.52h4.082v-.52c-1.162-.103-1.306-.26-1.306-.923V3.602l.431.013c1.934.062 2.434.301 2.693 1.846h.479L12.258 3z"/>
                                                                        </svg>
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <input type="number" min="0" max="100" value="<?php echo $timer_text_heading_font_size_value; ?>" class="form-control timer_text_heading_font_size_value" name="timer_text_heading_font_size_value" id="timer_text_heading_font_size_value_id" aria-label="Sizing example input" aria-describedby="inputGroup-timer_text_heading_font-sizing-sm_id">
                                                                        <span class="input-group-text" id="inputGroup-timer_text_heading_font-sizing-sm_id" style="padding:0px;" title="range is from 0 to 100">
                                                                            <select class="form-select form-select-sm timer_text_heading_font_size_unit" aria-label=".form-select-sm example" style="min-height: -webkit-fill-available;" id="timer_text_heading_font_size_unit_id" name="timer_text_heading_font_size_unit">
                                                                                <option selected value="<?php echo $timer_text_heading_font_size_unit; ?>">px</option>
                                                                                <!-- <option value="rem">rem</option>
                                                                                <option value="em">em</option>
                                                                                <option value="in">in</option> -->
                                                                            </select>
                                                                        </span>
                                                                    </div>    
                                                                </div>
                                                                <div class="col-sm-12 col-md-4 col-xl-auto button_text_font_size_div">
                                                                    <h6 class="style___h6">Button Text Font-size
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fonts" viewBox="0 0 16 16">
                                                                            <path d="M12.258 3h-8.51l-.083 2.46h.479c.26-1.544.758-1.783 2.693-1.845l.424-.013v7.827c0 .663-.144.82-1.3.923v.52h4.082v-.52c-1.162-.103-1.306-.26-1.306-.923V3.602l.431.013c1.934.062 2.434.301 2.693 1.846h.479L12.258 3z"/>
                                                                        </svg>
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <input type="number" min="0" max="100" value="<?php echo $button_text_font_size_value; ?>" class="form-control button_text_font_size_value" name="button_text_font_size_value" id="button_text_font_size_value_id" aria-label="Sizing example input" aria-describedby="inputGroup-button_text_font-sizing-sm_id">
                                                                        <span class="input-group-text" id="inputGroup-button_text_font-sizing-sm_id" style="padding:0px;" title="range is from 0 to 100">
                                                                            <select class="form-select form-select-sm button_text_font_size_unit" aria-label=".form-select-sm example" style="min-height: -webkit-fill-available;" id="button_text_font_size_unit_id" name="button_text_font_size_unit">
                                                                                <option selected value="<?php echo $button_text_font_size_unit; ?>">px</option>
                                                                                <!-- <option value="rem">rem</option>
                                                                                <option value="em">em</option>
                                                                                <option value="in">in</option> -->
                                                                            </select>
                                                                        </span>
                                                                    </div>    
                                                                </div>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="accordion-item">
                                                    <h2 class="accordion-header" id="style_font_family_config_heading_id">
                                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#style_font_family_config_collapse_id" aria-expanded="false" aria-controls="style_font_family_config_collapse_id">
                                                            Font-Family&emsp;
                                                            
                                                        </button>
                                                    </h2>
                                                    <div id="style_font_family_config_collapse_id" class="accordion-collapse collapse" aria-labelledby="style_font_family_config_heading_id" data-bs-parent="#style__config_accordion_id">
                                                        <div class="accordion-body">
                                                            <div class="row color__style">
                                                                <div class="col-sm-12 col-md-4 col-xl-auto message_text_font_family_div">
                                                                    <h6 class="style___h6">Message Text Font-family
                                                                    
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <select class="form-select form-select-sm message_text_font_family_selector" id="message_text_font_family_selector_id" name="message_text_font_family_selector" aria-label=".form-select-sm example">
                                                                            <option selected data-imagesrc='./icons/more_options_icon.jpg' data-description='Selected Font'>Select Font Family</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                            
                                                                <div class="col-sm-12 col-md-4 col-xl-auto timer_digit_font_family_div">
                                                                    <h6 class="style___h6">Timer Digit Font-family
                                                                        
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <select class="form-select form-select-sm timer_digit_font_family_selector" id="timer_digit_font_family_selector_id" name="timer_digit_font_family_selector" aria-label=".form-select-sm example">
                                                                            <option selected data-imagesrc='./icons/more_options_icon.jpg' data-description='Selected Font'>Select Font Family</option>
                                                                        </select>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12 col-md-4 col-xl-auto timer_heading_text_font_family_div">
                                                                    <h6 class="style___h6">Timer Digit Font-family
                                                                        
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <select class="form-select form-select-sm timer_heading_text_font_family_selector" id="timer_heading_text_font_family_selector_id" name="timer_heading_text_font_family_selector" aria-label=".form-select-sm example">
                                                                            <option selected data-imagesrc='./icons/more_options_icon.jpg' data-description='Selected Font'>Select Font Family</option>
                                                                        </select>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12 col-md-4 col-xl-auto button_label_font_family_div">
                                                                    <h6 class="style___h6">Button Label Font-family
                                                                        
                                                                    </h6>
                                                                    <div class="input-group input-group-sm mb-3">
                                                                        <select class="form-select form-select-sm button_label_font_family_selector" id="button_label_font_family_selector_id" name="button_label_font_family_selector" aria-label=".form-select-sm example">
                                                                            <option selected data-imagesrc='./icons/more_options_icon.jpg' data-description='Selected Font'>Select Font Family</option>
                                                                        </select>
                                                                    </div>
                                                                </div>

                                                                <!-- <div class="row font__style">
                                                                    <select class="form-select form-select-sm font_family_selector" id="font_family_selector_id" name="font_family_selector" aria-label=".form-select-sm example">
                                                                        <option selected data-imagesrc='./icons/more_options_icon.jpg' data-description='Selected Font'>Select Font Family</option>
                                                                    </select>
                                                                </div> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>


                                        </section>
                                    </div>
                                </div>
                                


                                <!-- ///////////////////////////////////////////////////////////////////////////////// -->
                                <div class="card save_preview_card" id="save_preview_card_id">

                                    <h5 class="card-header preview_card-header">Preview
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-up-square preview_card__header_close_icon_class" viewBox="0 0 16 16">
                                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                                            <path d="M3.544 10.705A.5.5 0 0 0 4 11h8a.5.5 0 0 0 .374-.832l-4-4.5a.5.5 0 0 0-.748 0l-4 4.5a.5.5 0 0 0-.082.537z" />
                                        </svg>

                                        <button type="submit" class="btn btn-primary save_preview_btn" id="save_preview_btn_id">Submit</button>
                                        <span id="saving___preview_btn_id">Saving...</span>
                                    </h5>
                                    <!-- <nav>
                                        <div class="nav nav-tabs" id="nav_tab_preview_output_id" role="tablist">
                                            <button class="nav-link active" id="nav-message-tab" data-bs-toggle="tab" data-bs-target="#nav-message" type="button" role="tab" aria-controls="nav-message" aria-selected="true">Sale CountdownBar ::</button>
                                        </div>
                                    </nav> -->

                                    <div class="card-body preview_card-body card-announcement-preview" value='1'>
                                        <div class="container preview_output_" id="preview_output_id">
                                            <div class="row">
                                                <div class="col-sm-12 preview_output_Div" id="preview_output_Div_id">

                                                    <div class="tab-content" id="nav-tabContent">
                                                        <div class="tab-pane fade show active" id="nav-message" role="tabpanel" aria-labelledby="nav-message-tab">
                                                            <div class="container announcement" id="announcement_message_bar">
                                                                <div class="row">
                                                                    <div class="col-sm-12 announcement_message_bar_text" id="Sale_announcement__bar-id">
                                                                        
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ///////////////////////////////////////////////////////////////////////////////// -->

                            </div>
                            <!--  Home container end   ////////// -->
                        </div>
                        <!--  Home Tab end   ////////// -->

                    </div>
                </section>

            </section>


            <script>
                $(function() {
                    // Initializes and creates emoji set from sprite sheet
                    window.emojiPicker = new EmojiPicker({
                        emojiable_selector: '[data-emojiable=true]',
                        assetsPath: 'http://onesignal.github.io/emoji-picker/lib/img/',
                        popupButtonClasses: 'fa fa-smile-o',
                    });
                    // Finds all elements with `emojiable_selector` and converts them to rich emoji input fields
                    // You may want to delay this step if you have dynamically created input fields that appear later in the loading process
                    // It can be called as many times as necessary; previously converted input fields will not be converted again
                    window.emojiPicker.discover();
                });

                document.getElementById('Sale_announcement__bar-id').innerHTML = `
                    <div class="row sale_preview_row__" id="sale_preview_row__id">
                        <div class="col-sm-12 col-md-auto ">
                            <span class="sale_preview_text_message_first_half" id="sale_preview_text_message_first_half_id"><?php echo $message_text1; ?></span>
                        </div>
                        <div class="col-sm-12 col-md-auto  sale_preview__countdownbar_timer_div" style="align-items: center;">
                            <div class="sale_preview__countdownbar_timer" id="sale_preview__countdownbar_timer_id"></div>
                        </div>
                        <div class="col-sm-12 col-md-auto sale_preview__countdownbar_sale_btn_div">
                            <span class="sale_preview_text_message_second_half" id="sale_preview_text_message_second_half_id"><?php echo $message_text2; ?></span>
                            <a class="btn btn-primary btn-sm sale_preview__countdownbar_sale_btn sale_preview__countdownbar_sale_btn_a_" href="<?php echo $saleButton_link; ?>"><?php echo $saleButton_label; ?></a>
                        </div>
                    </div>
                `;
                // $('#sale_preview__countdownbar_timer_id').css('transform','scale(0.8,0.8)');



                // $(function() {
                //     $("#dropbox, #background_imagefile_id").html5Uploader({
                //         name: 'ImagesData',
                //         postUrl: "<?php echo route('Upload_image_file_'); ?>"
                //     });
                // });    

                // $(document).ready(function(){
                //     $('#filer_input').filer({
                //         showThumbs: true,
                //         addMore: true,
                //         allowDuplicates: false,
                //         changeInput: true,
                //         fileMaxSize: 3,
                //         limit: 1,
                //     });
                // });

                // var file_extension_select_error = '';
                // $("#filer_input").click(function () {
                //     // var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
                //     var fileExtension = ['jpeg', 'jpg', 'png'];
                //     if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                //         alert("Only formats are allowed : "+fileExtension.join(', '));
                //         file_extension_select_error = "Only formats are allowed : "+fileExtension.join(', ');
                //     }
                // });
                //Example 2 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                $("#filer_input").filer({
                    limit: 2,
                    maxSize: 10,
                    extensions: null,
                    changeInput: '<div class="jFiler-input-dragDrop"><div class="jFiler-input-inner"><div class="jFiler-input-icon"><i class="icon-jfi-cloud-up-o"></i></div><div class="jFiler-input-text"><h3>Drag&Drop files here</h3> <span style="display:inline-block; margin: 15px 0">or</span></div><a class="jFiler-input-choose-btn blue">Browse Files</a></div></div>',
                    showThumbs: true,
                    theme: "dragdropbox",
                    templates: {
                        box: '<ul class="jFiler-items-list jFiler-items-grid"></ul>',
                        item: '<li class="jFiler-item">\
                                    <div class="jFiler-item-container">\
                                        <div class="jFiler-item-inner">\
                                            <div class="jFiler-item-thumb">\
                                                <div class="jFiler-item-status"></div>\
                                                <div class="jFiler-item-thumb-overlay">\
                                                    <div class="jFiler-item-info">\
                                                        <div style="display:table-cell;vertical-align: middle;">\
                                                            <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name}}</b></span>\
                                                            <span class="jFiler-item-others">{{fi-size2}}</span>\
                                                        </div>\
                                                    </div>\
                                                </div>\
                                                {{fi-image}}\
                                            </div>\
                                            <div class="jFiler-item-assets jFiler-row">\
                                                <ul class="list-inline pull-left">\
                                                    <li>{{fi-progressBar}}</li>\
                                                </ul>\
                                                <ul class="list-inline pull-right">\
                                                    <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                                </ul>\
                                            </div>\
                                        </div>\
                                    </div>\
                                </li>',
                        itemAppend: '<li class="jFiler-item">\
                                        <div class="jFiler-item-container">\
                                            <div class="jFiler-item-inner">\
                                                <div class="jFiler-item-thumb">\
                                                    <div class="jFiler-item-status"></div>\
                                                    <div class="jFiler-item-thumb-overlay">\
                                                        <div class="jFiler-item-info">\
                                                            <div style="display:table-cell;vertical-align: middle;">\
                                                                <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name}}</b></span>\
                                                                <span class="jFiler-item-others">{{fi-size2}}</span>\
                                                            </div>\
                                                        </div>\
                                                    </div>\
                                                    {{fi-image}}\
                                                </div>\
                                                <div class="jFiler-item-assets jFiler-row">\
                                                    <ul class="list-inline pull-left">\
                                                        <li><span class="jFiler-item-others">{{fi-icon}}</span></li>\
                                                    </ul>\
                                                    <ul class="list-inline pull-right">\
                                                        <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                                    </ul>\
                                                </div>\
                                            </div>\
                                        </div>\
                                    </li>',
                        progressBar: '<div class="bar"></div>',
                        itemAppendToEnd: false,
                        canvasImage: true,
                        removeConfirmation: true,
                        _selectors: {
                            list: '.jFiler-items-list',
                            item: '.jFiler-item',
                            progressBar: '.bar',
                            remove: '.jFiler-item-trash-action'
                        }
                    },
                    dragDrop: {
                        dragEnter: null,
                        dragLeave: null,
                        drop: null,
                        dragContainer: null,
                    },
                    uploadFile: {
                        url: "<?php echo route('Upload_image_file_'); ?>",
                        data: null,
                        type: 'POST',
                        enctype: 'multipart/form-data',
                        synchron: true,
                        beforeSend: function(){
                            // alert('you want to upload file?');
                        },
                        success: function(data, itemEl, listEl, boxEl, newInputEl, inputEl, id){
                            // console.log(JSON.parse(data));
                            
                            var parent = itemEl.find(".jFiler-jProgressBar").parent(),
                                new_file_name = JSON.parse(data),
                                filerKit = inputEl.prop("jFiler");
                                console.log(filerKit);
                            filerKit.files_list[id].name = new_file_name;

                            var imageUrl = '<?php echo env('APP_URL',''). '/assets/uploads/';?>' + new_file_name;
                            $("#sale_preview_row__id").css("background-image", "url(" + imageUrl + ")");
                            $('#filer_input_name').val(new_file_name);

                            itemEl.find(".jFiler-jProgressBar").fadeOut("slow", function(){
                                $("<div class=\"jFiler-item-others text-success\"><i class=\"icon-jfi-check-circle\"></i> Success</div>").hide().appendTo(parent).fadeIn("slow");
                            });
                        },
                        error: function(el){
                            var parent = el.find(".jFiler-jProgressBar").parent();
                            el.find(".jFiler-jProgressBar").fadeOut("slow", function(){
                                $("<div class=\"jFiler-item-others text-error\"><i class=\"icon-jfi-minus-circle\"></i> Error. </div>").hide().appendTo(parent).fadeIn("slow");
                            });
                            $("#sale_preview_row__id").css("background-image", "none");
                            $('#filer_input_name').val("");
                        },
                        statusCode: null,
                        onProgress: null,
                        onComplete: null
                    },
                    files: null,
                    addMore: false,
                    allowDuplicates: true,
                    clipBoardPaste: true,
                    excludeName: null,
                    beforeRender: null,
                    afterRender: null,
                    beforeShow: null,
                    beforeSelect: null,
                    onSelect: null,
                    afterShow: null,
                    onRemove: function(itemEl, file, id, listEl, boxEl, newInputEl, inputEl){
                        var filerKit = inputEl.prop("jFiler"),
                            file_name = filerKit.files_list[id].name;

                        $.post('<?php echo route("Delete_image_file_"); ?>', {file: file_name});
                        $("#sale_preview_row__id").css("background-image", "none");
                    },
                    onEmpty: null,
                    options: null,
                    dialogs: {
                        alert: function(text) {
                            return alert(text);
                        },
                        confirm: function (text, callback) {
                            confirm(text) ? callback() : null;
                        }
                    },
                    captions: {
                        button: "Choose Files",
                        feedback: "Choose files To Upload",
                        feedback2: "files were chosen",
                        drop: "Drop file here to Upload",
                        removeConfirmation: "Are you sure you want to remove this file?",
                        errors: {
                            filesLimit: "Only {{fi-limit}} files are allowed to be uploaded.",
                            filesType: "Only Images are allowed to be uploaded.",
                            filesSize: "{{fi-name}} is too large! Please upload file up to {{fi-maxSize}} MB.",
                            filesSizeAll: "Files you've choosed are too large! Please upload files up to {{fi-maxSize}} MB."
                        }
                    }
                });
                  
               
                // $("#background_imagefile__upload_image_btn_id").on("click", function() {
                    
                //     var formData = new FormData();
                //     formData.append('section', 'general');
                //     formData.append('action', 'previewImg');
                //     // Attach file
                //     formData.append('image', $('#fileInput')[0].files[0]); 
                //     $.ajax({
                //         url: '<?php echo route('Upload_image_file_'); ?>',
                //         data: formData,
                //         type: 'POST',
                //         contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                //         processData: false, // NEEDED, DON'T OMIT THIS
                //         // ... Other options like success and etc
                //     });

                // });
                


                // $("#background_imagefile__upload_image_btn_id").on("click", function() {
                //     // $("#background_imagefile__upload_image_btn_id").hide();
                //     // $("#saving___preview_btn_id").show();
                //     $.ajax({
                //         type: "POST",
                //         url: '<?php echo route('Upload_image_file_'); ?>',
                //         data: {
                //             _token: "<?php echo csrf_token(); ?>",
                //             ext : $("input[type=file]#background_imagefile_id").val().split('.').pop().toLowerCase(),
                //             fetch_shop__: "<?php echo $shop; ?>",
                //             image_name: ( ($("input[type=file]#background_imagefile_id")[0].files.length) ? $("input[type=file]#background_imagefile_id")[0].files[0].name : "" ).toLowerCase() ,
                //         },
                //         success: function(data) {
                //             console.log(data);
                //             // $("#saving___preview_btn_id").hide();
                //             // $("#background_imagefile__upload_image_btn_id").show();
                //         },
                //         error: function(data) {
                //             console.log((data));
                //         }
                //     }); // ----  end  ajax
                // });


                $("#saving___preview_btn_id").hide();

                $("#save_preview_btn_id").on("click", function() {
                    $("#save_preview_btn_id").hide();
                    $("#saving___preview_btn_id").show();
                    $.ajax({
                        type: "POST",
                        url: '<?php echo route('save_message_data_'); ?>',
                        data: {
                            _token: "<?php echo csrf_token(); ?>",
                            fetch_shop__: "<?php echo $shop; ?>",
                            message_text1: $('#content_message_text1_id').val(),
                            message_text2: $('#content_message_text2_id').val(),
                            saleButton_label: $('#saleButton_label_id').val(),
                            saleButton_link: $('#saleButton_link_id').val(),
                            TimeZoneSelector_select: $('#TimeZoneSelector-select-id').val(),
                            scheduling_sale_date: $('#scheduling_sale_date').val(),
                            scheduling_sale_time: $('#scheduling_sale_time').val(),
                            background_color: $('#background_colorpicked_id').val(),
                            background_opacity: $('input[type=range]#background_step_selector_id').val(),
                            image_file_name: $("#filer_input_name").val(),
                            message_text_color: $('#message_text_colorpicked_id').val(),
                            button_text_color: $('#button_text_colorpicked_id').val(),
                            timer_text_color: $('#timer_text_colorpicked_id').val(),
                            button_background_color: $('#button_background_colorpicked_id').val(),
                            timer_background_color: $('#timer_background_colorpicked_id').val(),
                            timer_heading_color: $('#timer_heading_colorpicked_id').val(),
                            message_text_font_size_value: $('#message_text_font_size_value_id').val(),
                            message_text_font_unit_value: $('#message_text_font_size_unit_id').val(),
                            timer_digit_font_size_value: $('#timer_digit_font_size_value_id').val(),
                            timer_digit_font_size_unit: $('#timer_digit_font_size_unit_id').val(),
                            timer_text_heading_font_size_value: $('#timer_text_heading_font_size_value_id').val(),
                            timer_text_heading_font_size_unit: $('#timer_text_heading_font_size_unit_id').val(),
                            button_text_font_size_value: $('#button_text_font_size_value_id').val(),
                            button_text_font_size_unit: $('#button_text_font_size_unit_id').val(),
                            message_text_font_family_selector: $('#message_text_font_family_selector_id').val(),
                            timer_digit_font_family_selector: $('#timer_digit_font_family_selector_id').val(),
                            timer_heading_text_font_family_selector: $('#timer_heading_text_font_family_selector_id').val(),
                            button_label_font_family_selector: $('#button_label_font_family_selector_id').val(),

                            
                        },
                        success: function(data) {
                            $("#saving___preview_btn_id").hide();
                            $("#save_preview_btn_id").show();
                            location.reload();
                        },
                        error: function(data) {
                            console.log((data));
                        }
                    }); // ----  end  ajax
                });


                // ( ($("input[type=file]#background_imagefile_id")[0].files.length) ? $("input[type=file]#background_imagefile_id")[0].files[0].name : "" ).toLowerCase()
                // $("input[type=file]#background_imagefile_id").val().split('.').pop().toLowerCase()
                // $("#background_imagefile__preview_image_id").prop('src', '<?php // echo getcwd(); 
                                                                                ?>/assets/upload/onimage__nws.png')
                // $("#background_imagefile__preview_image_id").prop('src', '<?php  // echo env('APP_URL',''); 
                                                                                ?>/assets/uploads/onimage__nws.png');

                // $("#background_imagefile__upload_image_btn_id").hide();
                // function show_hide__upload_button__() {
                //     if ($("#background_imagefile_text_id").text() == '') {
                //         $("#background_imagefile__upload_image_btn_id").hide();
                //     } else {
                //         $("#background_imagefile__upload_image_btn_id").show();
                //     }
                // }
                // window.setInterval('show_hide__upload_button__()', 1000);
                // window.setInterval(
                //     function() {
                //         $("#background_imagefile_text_id").prop('innerHTML', ($("input[type=file]#background_imagefile_id")[0].files.length) ? $("input[type=file]#background_imagefile_id")[0].files[0].name : "");

                //     }, 300);


                /*
                $("#content_message_timepicker_id").datetimepicker({
                    // parent container
                    container: 'body',
                    // language
                    // you can find all languages under the locales folder
                    // attribute: data-date-language
                    language: 'en',
                    // RTL mode
                    rtl: false,
                    // step size
                    // attributes: data-minute-step
                    minuteStep: 5,
                    // attributes: data-picker-position
                    pickerPosition: 'bottom-right',
                    // enable meridian views for day and hour views
                    // attributes: data-show-meridian
                    showMeridian: false,
                    // initial date
                    initialDate: new Date('now'),
                    // z-index property
                    // attributes: data-z-index
                    zIndex: undefined,
                    // ISO-8601 valid datetime
                    format: 'yyyy-mm-dd hh:mm:ss',
                    // 0 = Sunday
                    // 6 = Saturday
                    // attributes: data-date-weekstart
                    weekStart: 0,
                    // start/end dates
                    // attributes: data-date-startdate and data-date-enddate
                    startDate: -Infinity,
                    endDate: Infinity,
                    // days of the week that should be disabled
                    // 0 = Sunday
                    // 6 = Saturday
                    // attributes: data-date-days-of-week-disabled
                    daysOfWeekDisabled: [],
                    // auto close the picker after selection
                    // attributes: data-date-autoclose
                    // autoclose: false,
                    // auto close the picker after selection
                    // attributes: data-date-autoclose
                    autoclose: true,
                    // 0 or 'hour' for the hour view
                    // 1 or 'day' for the day view
                    // 2 or 'month' for month view (the default)
                    // 3 or 'year' for the 12-month overview
                    // 4 or 'decade' for the 10-year overview. 
                    // attributes: data-start-view
                    startView: 2,
                    // attributes:data-min-view
                    minView: 0,
                    // attributes: data-max-view
                    maxView: 4,
                    // select the view from which the date will be selected
                    // 'decade', 'year', 'month', 'day', 'hour'
                    // attributes: data-view-select
                    viewSelect: 0,
                    // show Today button
                    // attributes: data-date-today-btn
                    todayBtn: true,
                    // highlight the current date
                    todayHighlight: true,
                    // enable keyboard navigation
                    // attributes: data-date-keyboard-navigation

                    // keyboard<a href="https://www.jqueryscript.net/tags.php?/Navigation/">Navigation</a>: true,

                    // whether or not to force parsing of the input value when the picker is closed
                    // attributes: data-date-force-parse
                    forceParse: false,
                });
                */
            </script>
            <script>
                var clock;
                $(document).ready(function() {
                    // Set dates.
                    var futureDate = new Date("<?php echo $scheduling_sale_date . " " . $scheduling_sale_time; ?>");
                    var currentDate = new Date();
                    // Calculate the difference in seconds between the future and current date
                    var diff = futureDate.getTime() / 1000 - currentDate.getTime() / 1000;
                    // Calculate day difference and apply class to .clock for extra digit styling.
                    function dayDiff(first, second) {
                        return (second - first) / (1000 * 60 * 60 * 24);
                    }
                    if (dayDiff(currentDate, futureDate) < 100) {
                        $('.clock').addClass('twoDayDigits');
                    } else {
                        $('.clock').addClass('threeDayDigits');
                    }
                    if (diff < 0) {
                        diff = 0;
                    }
                    // Instantiate a coutdown FlipClock
                    clock = $('#sale_preview__countdownbar_timer_id').FlipClock(diff, {
                        clockFace: 'DailyCounter',
                        countdown: true
                    });
                });

                // function DATE_Time_SALE_TIMER____(DATE_string) {
                    //     var countDownDate = new Date(DATE_string).getTime();
                    //     var x = setInterval(function() {
                    //         var now = new Date().getTime();
                    //         var distance = countDownDate - now;

                    //         var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    //         var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    //         var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    //         var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    //         document.getElementById("demo").innerHTML = days + "d " + hours + "h " +
                    //             minutes + "m " + seconds + "s ";

                    //         // If the count down is over, write some text 
                    //         if (distance < 0) {
                    //             clearInterval(x);
                    //             document.getElementById("demo").innerHTML = "EXPIRED";
                    //         }
                    //     }, 1000);
                // }


                // window.setInterval(function(){
                //     if( $('.content_card__body').attr('value') == 1 ){
                //         $('.style_card__body').attr('value', 0);
                //         $('.background_card__body').attr('value',0);
                //         $('.style_card__body').hide();
                //     }
                // }, 1000);

                $("#sale_preview_row__id").css( "background-color", hexToRgbA__colorpicker( $('#background_colorpicked_id').val() , $('input[type=range]#background_step_selector_id').val() ) );
                $("#sale_preview_row__id").css( "background-image",  "<?php  echo  ($image_file_name != "") ?  "url(".( env('APP_URL' , ''). "/assets/uploads/" . $image_file_name).")" : "none" ; ?>" );
                $("#sale_preview_row__id .sale_preview_text_message_first_half").css( "color", hexToRgbA__colorpicker( $('#message_text_colorpicked_id').val(), 1 ) );
                $("#sale_preview_row__id .sale_preview_text_message_second_half").css( "color", hexToRgbA__colorpicker( $('#message_text_colorpicked_id').val() , 1 ) );
                $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "color", hexToRgbA__colorpicker( $('#button_text_colorpicked_id').val() , 1 ) );
                // $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "background", hexToRgbA__colorpicker( $('#button_text_colorpicked_id').val() , 1 ) );
                $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "border-color", hexToRgbA__colorpicker( $('#button_text_colorpicked_id').val() , 1 ) );
                $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "background", hexToRgbA__colorpicker( $('#button_background_colorpicked_id').val() , 1 ) );
                $(".flip-clock-label").css( "color", $('#timer_heading_colorpicked_id').val() );
                $(".flip-clock-wrapper ul li a div div.inn").css( "background", $('#timer_background_colorpicked_id').val().trim() ); 
                $(".flip-clock-wrapper ul li a div div.inn").css( "color", $('#timer_text_colorpicked_id').val().trim() );
                $("span.flip-clock-dot.top").css( "color", $('#timer_text_colorpicked_id').val().trim() );
                $("span.flip-clock-dot.bottom").css( "color", $('#timer_text_colorpicked_id').val().trim() );
                ///////////     fonts initial states loading 
                $('.sale_preview_text_message_first_half').css('font-size', $('input#message_text_font_size_value_id').val() + $('#message_text_font_size_unit_id').val() );
                $('.sale_preview_text_message_second_half').css('font-size', $('input#message_text_font_size_value_id').val() + $('#message_text_font_size_unit_id').val() );
                $('#sale_preview_row__id .flip-clock-wrapper ul li a div div.inn').css('font-size', $('input#timer_digit_font_size_value_id').val() + $('#timer_digit_font_size_unit_id').val() );
                $('.flip-clock-divider .flip-clock-label').css('font-size', ($('input#timer_text_heading_font_size_value_id').val() + $('#timer_text_heading_font_size_unit_id').val()) );
                
                
                
                
                $('#background_colorpicked_id').on('input',function() {
                    // $("#sale_preview_row__id").css("background-color",  $(this).val() );
                    $("#sale_preview_row__id").css( "background-color", hexToRgbA__colorpicker( $(this).val() , $('input[type=range]#background_step_selector_id').val() ) );
                });
                function background_Opacity_Onchange_function(params_value) {
                    $("#sale_preview_row__id").css( "background-color", hexToRgbA__colorpicker( $('#background_colorpicked_id').val() , params_value) );
                }

                $('#message_text_colorpicked_id').on('input',function() {
                    $("#sale_preview_row__id .sale_preview_text_message_first_half").css( "color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                    $("#sale_preview_row__id .sale_preview_text_message_second_half").css( "color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                });
                $('#button_text_colorpicked_id').on('input',function() {
                    $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                });
                $('#button_background_colorpicked_id').on('input',function() {
                    $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "background", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                    $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css( "border-color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                });
                $('#timer_heading_colorpicked_id').on('input',function() {
                    $(".flip-clock-label").css( "color", hexToRgbA__colorpicker( $(this).val() , 1 ));
                });
                $('#timer_text_colorpicked_id').on('input',function() {
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.inn").css( "color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                });
                $('#timer_background_colorpicked_id').on('change',function() {
                    $("span.flip-clock-dot top").css( "color", $(this).val().trim() );
                    $("span.flip-clock-dot.bottom").css( "color", $(this).val().trim() );
                    // $(".flip-clock-wrapper ul li a div div.inn").css( "background", $('#timer_background_colorpicked_id').val().trim() ); 
                    // $("span.flip-clock-dot.top").css( "background-color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                    // $("span.flip-clock-dot.bottom").css( "background-color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                    // $("div.flip-clock-wrapper ul:after").css( "background-color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                    // $("div.flip-clock-wrapper ul:before").css( "background-color", hexToRgbA__colorpicker( $(this).val() , 1 ) );
                });
                function change__timer_color() {
                    $(".flip-clock-wrapper ul li a div div.inn").css( "background", $('#timer_background_colorpicked_id').val().trim() ); 
                    $(".flip-clock-wrapper ul li a div div.inn").css( "color", $('#timer_text_colorpicked_id').val().trim() );
                }
                window.setInterval('change__timer_color()', 100);
                
                

                $('input#message_text_font_size_value_id').on('input', function(){ 
                    $('.sale_preview_text_message_first_half').css('font-size', $(this).val() + $('#message_text_font_size_unit_id').val() );
                    $('.sale_preview_text_message_second_half').css('font-size', $(this).val() + $('#message_text_font_size_unit_id').val() );
                });
                $('input#timer_digit_font_size_value_id').on('input', function(){ 
                    $('#sale_preview_row__id .flip-clock-wrapper ul li a div div.inn').css('font-size', $(this).val() + $('#timer_digit_font_size_unit_id').val() );
                });
                $('input#button_text_font_size_value_id').on('input', function(){ 
                    $('.sale_preview__countdownbar_sale_btn_a_').css('font-size', $(this).val() + $('#button_text_font_size_unit_id').val() );
                });
                $('input#timer_text_heading_font_size_value_id').on('input', function(){ 
                    $('.flip-clock-divider .flip-clock-label').css('font-size', $(this).val() + $('#timer_text_heading_font_size_unit_id').val() );
                });



                // $('.flip-clock-wrapper ul li a div div.inn').css('background', 'red');

                function hexToRgbA__colorpicker(hex, opt){
                    var opacity = 1;
                    var opacity = opt;
                    var c;
                    if(/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)){
                        c = hex.substring(1).split('');
                        if(c.length== 3){
                            c = [c[0], c[0], c[1], c[1], c[2], c[2]];
                        }
                        c = '0x'+c.join('');
                        return 'rgba('+[(c>>16)&255, (c>>8)&255, c&255].join(',')+','+ opacity +')';
                    }
                    throw new Error('Bad Hex');
                }

                var fonts = ["Montez", "Lobster", "Josefin Sans", "Shadows Into Light", "Pacifico", "Amatic SC", "Orbitron", "Rokkitt", "Righteous", "Dancing Script", "Bangers", "Chewy", "Sigmar One", "Architects Daughter", "Abril Fatface", "Covered By Your Grace", "Kaushan Script", "Gloria Hallelujah", "Satisfy", "Lobster Two", "Comfortaa", "Cinzel", "Courgette"];
                var string = "";
                
                // var select = document.getElementById("element_font_selector");
                // for (var a = 0; a < fonts.length; a++) {
                //     var opt = document.createElement('option');
                //     opt.value = opt.innerHTML = fonts[a];
                //     opt.style.fontFamily = fonts[a];
                //     select.add(opt);
                // }
                //////////////////////////////////////////////////////////////////////////////////////////////////////
                ////         ADD  Font-Family Selector Options with jquery
                //////////////////////////////////////////////////////////////////////////////////////////////////////
                function add__font_family_names_inSelectors(selector_ID , fonts_array) {
                    var select = document.getElementById(selector_ID);
                    for (var a = 0; a < fonts_array.length; a++) {
                        var opt = document.createElement('option');
                        opt.value = opt.innerHTML = fonts_array[a];
                        opt.style.fontFamily = fonts_array[a];
                        select.add(opt);
                    }
                }
                add__font_family_names_inSelectors("message_text_font_family_selector_id", fonts);
                add__font_family_names_inSelectors("timer_digit_font_family_selector_id", fonts);
                add__font_family_names_inSelectors("timer_heading_text_font_family_selector_id", fonts);
                add__font_family_names_inSelectors("button_label_font_family_selector_id", fonts);
                
                //////////////////////////////////////////////////////////////////////////////////////////////////////
                ////         On change selector Values with jquery
                //////////////////////////////////////////////////////////////////////////////////////////////////////
                
            
                function change__fontFamily_selector__(selectorID, elementID) {
                    var x = document.getElementById(selectorID).selectedIndex;
                    var y = document.getElementById(selectorID).options;
                    $("#"+ selectorID).css('font-family', $(y[x]).val() );
                    $("#"+elementID).css('font-family',$(y[x]).val() );
                }
                
                $('#message_text_font_family_selector_id').on('input',function() {
                    var x = document.getElementById("message_text_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("message_text_font_family_selector_id").options;
                    $("#message_text_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_text_message_first_half_id").css('font-family',$(y[x]).val() );
                    $("#sale_preview_text_message_second_half_id").css('font-family',$(y[x]).val() );
                });
                $('#message_text_font_family_selector_id').on('change',function() {
                    var x = document.getElementById("message_text_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("message_text_font_family_selector_id").options;
                    $("#message_text_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_text_message_first_half_id").css('font-family',$(y[x]).val() );
                    $("#sale_preview_text_message_second_half_id").css('font-family',$(y[x]).val() );
                });
                
                $('#timer_digit_font_family_selector_id').on('input',function() {
                    var x = document.getElementById("timer_digit_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("timer_digit_font_family_selector_id").options;
                    $("#timer_digit_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.inn").css('font-family',$(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.shadow").css('font-family',$(y[x]).val() );
                });
                $('#timer_digit_font_family_selector_id').on('change',function() {
                    var x = document.getElementById("timer_digit_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("timer_digit_font_family_selector_id").options;
                    $("#timer_digit_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.inn").css('font-family',$(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.shadow").css('font-family',$(y[x]).val() );
                });
                function change_font_family_of_Timer_Digit() {
                    var x = document.getElementById("timer_digit_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("timer_digit_font_family_selector_id").options;
                    $("#timer_digit_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.inn").css('font-family',$(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-wrapper ul li a div div.shadow").css('font-family',$(y[x]).val() );
                }
                window.setInterval("change_font_family_of_Timer_Digit()", 500);

                $('#button_label_font_family_selector_id').on('input',function() {
                    var x = document.getElementById("button_label_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("button_label_font_family_selector_id").options;
                    $("#button_label_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css('font-family',$(y[x]).val() );
                });
                $('#button_label_font_family_selector_id').on('change',function() {
                    var x = document.getElementById("button_label_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("button_label_font_family_selector_id").options;
                    $("#button_label_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .sale_preview__countdownbar_sale_btn_a_").css('font-family',$(y[x]).val() );
                });
                $('#timer_heading_text_font_family_selector_id').on('input',function() {
                    var x = document.getElementById("timer_heading_text_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("timer_heading_text_font_family_selector_id").options;
                    $("#timer_heading_text_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-label").css('font-family',$(y[x]).val() );
                });
                $('#timer_heading_text_font_family_selector_id').on('change',function() {
                    var x = document.getElementById("timer_heading_text_font_family_selector_id").selectedIndex;
                    var y = document.getElementById("timer_heading_text_font_family_selector_id").options;
                    $("#timer_heading_text_font_family_selector_id").css('font-family', $(y[x]).val() );
                    $("#sale_preview_row__id .flip-clock-label").css('font-family',$(y[x]).val() );
                });
                
                
                $('#message_text_font_family_selector_id option[value="<?php echo $message_text_font_family_selector; ?>"]').prop("selected", true).trigger( "change" );
                $('#timer_digit_font_family_selector_id option[value="<?php echo $timer_digit_font_family_selector; ?>"]').prop("selected", true).trigger( "change" );
                $('#timer_heading_text_font_family_selector_id option[value="<?php echo $timer_heading_text_font_family_selector; ?>"]').prop("selected", true).trigger( "change" );
                $('#button_label_font_family_selector_id option[value="<?php echo $button_label_font_family_selector; ?>"]').prop("selected", true).trigger( "change" );

                function change__text_values____() {
                    $('#sale_preview_text_message_first_half_id').text( $('#content_message_text1_id').val() ).trigger("input");
                    $('#sale_preview_text_message_first_second_id').text( $('#content_message_text2_id').val() );
                    $('.sale_preview__countdownbar_sale_btn_a_').html( $('#saleButton_label_id').val() );
                    $('.sale_preview__countdownbar_sale_btn_a_').prop('href',$('#saleButton_link_id').val() );
                }
                window.setInterval("change__text_values____()", 500);

                // hexToRgbA__colorpicker($('#background_colorpicked_id').val(), 0.4)
                // hexToRgbA__colorpicker('#fbafff');
                // console.log(hexToRgbA__colorpicker($('#background_colorpicked_id').val(), $('#background_step_selector_id').val()));


                function show_hide_card_body(onclick, card_header_class, card_body_class, check_attribute_name, hide_when_value_is, show_when_value_is, card__header_close_icon_class, icon_float) {
                    $('.' + card__header_close_icon_class).css('float', icon_float);
                    $('.' + card_header_class).css('cursor', 'pointer');
                    $('.' + card_header_class).attr('unselectable', 'on').css('user-select', 'none').on('selectstart', false);
                    $('.' + card__header_close_icon_class).css({
                        WebkitTransform: 'rotate(' + '360' + 'deg)'
                    });

                    if ($('.' + card_body_class).attr(check_attribute_name) == hide_when_value_is) {
                        $('.' + card__header_close_icon_class).css({
                            WebkitTransform: 'rotate(' + '180' + 'deg)'
                        });
                        $('.' + card_body_class).hide();
                        $('.' + card_body_class).attr(check_attribute_name, show_when_value_is);
                    } else if ($('.' + card_body_class).attr(check_attribute_name) == show_when_value_is) {
                        $('.' + card__header_close_icon_class).css({
                            WebkitTransform: 'rotate(' + '360' + 'deg)'
                        });
                        $('.' + card_body_class).show();
                        $('.' + card_body_class).attr(check_attribute_name, hide_when_value_is);
                    }
                    $('.' + card_header_class).on(onclick, function() {
                        if ($('.' + card_body_class).attr(check_attribute_name) == hide_when_value_is) {
                            $('.' + card__header_close_icon_class).css({
                                WebkitTransform: 'rotate(' + '180' + 'deg)'
                            });
                            $('.' + card_body_class).hide();
                            $('.' + card_body_class).attr(check_attribute_name, show_when_value_is);
                        } else if ($('.' + card_body_class).attr(check_attribute_name) == show_when_value_is) {
                            $('.' + card__header_close_icon_class).css({
                                WebkitTransform: 'rotate(' + '360' + 'deg)'
                            });
                            $('.' + card_body_class).show();
                            $('.' + card_body_class).attr(check_attribute_name, hide_when_value_is);
                        }
                    });
                }
                show_hide_card_body('click', 'content_card__header', 'content_card__body', 'value', '1', '0', 'content_card__header_close_icon_class', 'right');
                show_hide_card_body('click', 'style_card__header', 'style_card__body', 'value', '1', '0', 'style_card__header_close_icon_class', 'right');
                show_hide_card_body('click', 'background_card__header', 'background_card__body', 'value', '1', '0', 'background_card__header_close_icon_class', 'right');
                show_hide_card_body('click', 'preview_card-header', 'preview_card-body', 'value', '1', '0', 'preview_card__header_close_icon_class', 'none');



                $('#alert_forDateExpire').hide();

                function customAlert(msg, duration) {
                    var styler = document.createElement("div");
                    styler.innerHTML = '<div class ="alert alert-success"role = "alert" >' + msg + '</div>';
                    styler.setAttribute("style", "width:auto;height:50px; padding:0px;");
                    setTimeout(function() {
                        styler.parentNode.removeChild(styler);
                    }, duration);
                    document.body.prepend(styler);
                }

                function formatAMPM(date) {
                    var hours = date.getHours();
                    var minutes = date.getMinutes();
                    var ampm = hours >= 12 ? 'pm' : 'am';
                    hours = hours % 12;
                    hours = hours ? hours : 12; // the hour '0' should be '12'
                    minutes = minutes < 10 ? '0' + minutes : minutes;
                    var strTime = hours + ':' + minutes + ' ' + ampm;
                    return strTime;
                }
                $('#scheduling_sale_date').change(function() {
                    // console.log($('#scheduling_sale_date').val());
                    var currentdate = new Date();
                    var datetime = currentdate.getFullYear() + "-" + (currentdate.getMonth() + 1) + "-" + currentdate.getDate();
                    // console.log(datetime);
                    var d1 = Date.parse(datetime);
                    var d2 = Date.parse($('#scheduling_sale_date').val());
                    if (d2 < d1) {
                        // alert ("Expire!");
                        $('#alert_forDateExpire').show();
                    } else {
                        $('#alert_forDateExpire').hide();
                    }
                    var s = (new Date(datetime + ' ' + new Date().toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1"))) > (new Date($('#scheduling_sale_date').val() + ' ' + $('#scheduling_sale_time').val()));
                    // console.log(s);
                    if (s) {
                        $('#alert_forDateExpire').show();
                    } else {
                        $('#alert_forDateExpire').hide();
                    }
                    //  console.log(Date.now());
                });

                function ondate_expire__() {
                    // console.log($('#scheduling_sale_date').val());
                    var currentdate = new Date();
                    var datetime = currentdate.getFullYear() + "-" + (currentdate.getMonth() + 1) + "-" + currentdate.getDate();
                    // console.log(datetime);
                    var d1 = Date.parse(datetime);
                    var d2 = Date.parse($('#scheduling_sale_date').val());
                    if (d2 < d1) {
                        // alert ("Expire!");
                        $('#alert_forDateExpire').show();
                    } else {
                        $('#alert_forDateExpire').hide();
                    }
                    var s = (new Date(datetime + ' ' + new Date().toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1"))) > (new Date($('#scheduling_sale_date').val() + ' ' + $('#scheduling_sale_time').val()));
                    // console.log(s);
                    if (s) {
                        $('#alert_forDateExpire').show();
                    } else {
                        $('#alert_forDateExpire').hide();
                    }
                    //  console.log(Date.now());
                }
                window.setInterval('ondate_expire__()', 1000);
                // console.log( $('#scheduling_sale_time').val() );
                $('#scheduling_sale_time').change(function() {
                    // console.log( $('#scheduling_sale_time').val() );
                    var currentdate = new Date();
                    var datetime = currentdate.getFullYear() + "-" + (currentdate.getMonth() + 1) + "-" + currentdate.getDate();

                    var s = (new Date(datetime + ' ' + new Date().toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1"))) > (new Date($('#scheduling_sale_date').val() + ' ' + $('#scheduling_sale_time').val()));
                    // console.log(s);
                    if (s) {
                        $('#alert_forDateExpire').show();
                    } else {
                        $('#alert_forDateExpire').hide();
                    }
                    //  console.log(Date.now());
                });

                function ontime_expire__() {
                    // console.log( $('#scheduling_sale_time').val() );
                    var currentdate = new Date();
                    var datetime = currentdate.getFullYear() + "-" + (currentdate.getMonth() + 1) + "-" + currentdate.getDate();

                    var s = (new Date(datetime + ' ' + new Date().toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1"))) > (new Date($('#scheduling_sale_date').val() + ' ' + $('#scheduling_sale_time').val()));
                    // console.log(s);
                    if (s) {
                        $('#alert_forDateExpire').show();
                    } else {
                        $('#alert_forDateExpire').hide();
                    }
                    //  console.log(Date.now());
                }
                window.setInterval('ontime_expire__()', 1000);
            </script>
            <script>
                //  TimeZoneSelector-select-id
                const timezones = [
                    "Etc/GMT+12",
                    "Pacific/Midway",
                    "Pacific/Honolulu",
                    "America/Juneau",
                    "America/Dawson",
                    "America/Boise",
                    "America/Chihuahua",
                    "America/Phoenix",
                    "America/Chicago",
                    "America/Regina",
                    "America/Mexico_City",
                    "America/Belize",
                    "America/Detroit",
                    "America/Indiana/Indianapolis",
                    "America/Bogota",
                    "America/Glace_Bay",
                    "America/Caracas",
                    "America/Santiago",
                    "America/St_Johns",
                    "America/Sao_Paulo",
                    "America/Argentina/Buenos_Aires",
                    "America/Godthab",
                    "Etc/GMT+2",
                    "Atlantic/Azores",
                    "Atlantic/Cape_Verde",
                    "GMT",
                    "Africa/Casablanca",
                    "Atlantic/Canary",
                    "Europe/Belgrade",
                    "Europe/Sarajevo",
                    "Europe/Brussels",
                    "Europe/Amsterdam",
                    "Africa/Algiers",
                    "Europe/Bucharest",
                    "Africa/Cairo",
                    "Europe/Helsinki",
                    "Europe/Athens",
                    "Asia/Jerusalem",
                    "Africa/Harare",
                    "Europe/Moscow",
                    "Asia/Kuwait",
                    "Africa/Nairobi",
                    "Asia/Baghdad",
                    "Asia/Tehran",
                    "Asia/Dubai",
                    "Asia/Baku",
                    "Asia/Kabul",
                    "Asia/Yekaterinburg",
                    "Asia/Karachi",
                    "Asia/Kolkata",
                    "Asia/Kathmandu",
                    "Asia/Dhaka",
                    "Asia/Colombo",
                    "Asia/Almaty",
                    "Asia/Rangoon",
                    "Asia/Bangkok",
                    "Asia/Krasnoyarsk",
                    "Asia/Shanghai",
                    "Asia/Kuala_Lumpur",
                    "Asia/Taipei",
                    "Australia/Perth",
                    "Asia/Irkutsk",
                    "Asia/Seoul",
                    "Asia/Tokyo",
                    "Asia/Yakutsk",
                    "Australia/Darwin",
                    "Australia/Adelaide",
                    "Australia/Sydney",
                    "Australia/Brisbane",
                    "Australia/Hobart",
                    "Asia/Vladivostok",
                    "Pacific/Guam",
                    "Asia/Magadan",
                    "Pacific/Fiji",
                    "Pacific/Auckland",
                    "Pacific/Tongatapu"
                ];
                const i18n = {
                    "Etc/GMT+12": "International Date Line West",
                    "Pacific/Midway": "Midway Island, Samoa",
                    "Pacific/Honolulu": "Hawaii",
                    "America/Juneau": "Alaska",
                    "America/Dawson": "Pacific Time (US and Canada); Tijuana",
                    "America/Boise": "Mountain Time (US and Canada)",
                    "America/Chihuahua": "Chihuahua, La Paz, Mazatlan",
                    "America/Phoenix": "Arizona",
                    "America/Chicago": "Central Time (US and Canada)",
                    "America/Regina": "Saskatchewan",
                    "America/Mexico_City": "Guadalajara, Mexico City, Monterrey",
                    "America/Belize": "Central America",
                    "America/Detroit": "Eastern Time (US and Canada)",
                    "America/Indiana/Indianapolis": "Indiana (East)",
                    "America/Bogota": "Bogota, Lima, Quito",
                    "America/Glace_Bay": "Atlantic Time (Canada)",
                    "America/Caracas": "Caracas, La Paz",
                    "America/Santiago": "Santiago",
                    "America/St_Johns": "Newfoundland and Labrador",
                    "America/Sao_Paulo": "Brasilia",
                    "America/Argentina/Buenos_Aires": "Buenos Aires, Georgetown",
                    "America/Godthab": "Greenland",
                    "Etc/GMT+2": "Mid-Atlantic",
                    "Atlantic/Azores": "Azores",
                    "Atlantic/Cape_Verde": "Cape Verde Islands",
                    "GMT": "Dublin, Edinburgh, Lisbon, London",
                    "Africa/Casablanca": "Casablanca, Monrovia",
                    "Atlantic/Canary": "Canary Islands",
                    "Europe/Belgrade": "Belgrade, Bratislava, Budapest, Ljubljana, Prague",
                    "Europe/Sarajevo": "Sarajevo, Skopje, Warsaw, Zagreb",
                    "Europe/Brussels": "Brussels, Copenhagen, Madrid, Paris",
                    "Europe/Amsterdam": "Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna",
                    "Africa/Algiers": "West Central Africa",
                    "Europe/Bucharest": "Bucharest",
                    "Africa/Cairo": "Cairo",
                    "Europe/Helsinki": "Helsinki, Kiev, Riga, Sofia, Tallinn, Vilnius",
                    "Europe/Athens": "Athens, Istanbul, Minsk",
                    "Asia/Jerusalem": "Jerusalem",
                    "Africa/Harare": "Harare, Pretoria",
                    "Europe/Moscow": "Moscow, St. Petersburg, Volgograd",
                    "Asia/Kuwait": "Kuwait, Riyadh",
                    "Africa/Nairobi": "Nairobi",
                    "Asia/Baghdad": "Baghdad",
                    "Asia/Tehran": "Tehran",
                    "Asia/Dubai": "Abu Dhabi, Muscat",
                    "Asia/Baku": "Baku, Tbilisi, Yerevan",
                    "Asia/Kabul": "Kabul",
                    "Asia/Yekaterinburg": "Ekaterinburg",
                    "Asia/Karachi": "Islamabad, Karachi, Tashkent",
                    "Asia/Kolkata": "Chennai, Kolkata, Mumbai, New Delhi",
                    "Asia/Kathmandu": "Kathmandu",
                    "Asia/Dhaka": "Astana, Dhaka",
                    "Asia/Colombo": "Sri Jayawardenepura",
                    "Asia/Almaty": "Almaty, Novosibirsk",
                    "Asia/Rangoon": "Yangon Rangoon",
                    "Asia/Bangkok": "Bangkok, Hanoi, Jakarta",
                    "Asia/Krasnoyarsk": "Krasnoyarsk",
                    "Asia/Shanghai": "Beijing, Chongqing, Hong Kong SAR, Urumqi",
                    "Asia/Kuala_Lumpur": "Kuala Lumpur, Singapore",
                    "Asia/Taipei": "Taipei",
                    "Australia/Perth": "Perth",
                    "Asia/Irkutsk": "Irkutsk, Ulaanbaatar",
                    "Asia/Seoul": "Seoul",
                    "Asia/Tokyo": "Osaka, Sapporo, Tokyo",
                    "Asia/Yakutsk": "Yakutsk",
                    "Australia/Darwin": "Darwin",
                    "Australia/Adelaide": "Adelaide",
                    "Australia/Sydney": "Canberra, Melbourne, Sydney",
                    "Australia/Brisbane": "Brisbane",
                    "Australia/Hobart": "Hobart",
                    "Asia/Vladivostok": "Vladivostok",
                    "Pacific/Guam": "Guam, Port Moresby",
                    "Asia/Magadan": "Magadan, Solomon Islands, New Caledonia",
                    "Pacific/Fiji": "Fiji Islands, Kamchatka, Marshall Islands",
                    "Pacific/Auckland": "Auckland, Wellington",
                    "Pacific/Tongatapu": "Nuku'alofa"
                }
                var select_timeZone = document.getElementById("TimeZoneSelector-select-id");
                for (var a = 0; a < timezones.length; a++) {
                    var opt = document.createElement('option');
                    opt.value = timezones[a];
                    opt.innerHTML = i18n[timezones[a]];
                    select_timeZone.add(opt);
                }


                // window.setInterval(  function() { $('#TimeZoneSelector-select-id').val('<?php //  echo $TimeZoneSelector_select; 
                                                                                            ?>').trigger('change'); }  , 1000);
                $('#TimeZoneSelector-select-id').val('<?php echo $TimeZoneSelector_select; ?>').trigger('change');
            </script>

            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->


        
            <script>
                (function($) {
                    $.fn.html5Uploader = function(options) {

                        var crlf = '\r\n';
                        var boundary = "iloveigloo";
                        var dashes = "--";

                        var settings = {
                            "name": "uploadedFile",
                            "postUrl": "Upload.aspx",
                            "onClientAbort": null,
                            "onClientError": null,
                            "onClientLoad": null,
                            "onClientLoadEnd": null,
                            "onClientLoadStart": null,
                            "onClientProgress": null,
                            "onServerAbort": null,
                            "onServerError": null,
                            "onServerLoad": null,
                            "onServerLoadStart": null,
                            "onServerProgress": null,
                            "onServerReadyStateChange": null,
                            "onSuccess": null
                        };

                        if (options) {
                            $.extend(settings, options);
                        }

                        return this.each(function(options) {
                            var $this = $(this);
                            if ($this.is("[type='file']")) {
                                $this
                                    .bind("change", function() {
                                        var files = this.files;
                                        for (var i = 0; i < files.length; i++) {
                                            fileHandler(files[i]);
                                        }
                                    });
                            } else {
                                $this
                                    .bind("dragenter dragover", function() {
                                        $(this).addClass("hover");
                                        return false;
                                    })
                                    .bind("dragleave", function() {
                                        $(this).removeClass("hover");
                                        return false;
                                    })
                                    .bind("drop", function(e) {
                                        $(this).removeClass("hover");
                                        var files = e.originalEvent.dataTransfer.files;
                                        for (var i = 0; i < files.length; i++) {
                                            fileHandler(files[i]);
                                        }
                                        return false;
                                    });
                            }
                        });

                        function fileHandler(file) {
                            var fileReader = new FileReader();
                            fileReader.onabort = function(e) {
                                if (settings.onClientAbort) {
                                    settings.onClientAbort(e, file);
                                }
                            };
                            fileReader.onerror = function(e) {
                                if (settings.onClientError) {
                                    settings.onClientError(e, file);
                                }
                            };
                            fileReader.onload = function(e) {
                                if (settings.onClientLoad) {
                                    settings.onClientLoad(e, file);
                                }
                            };
                            fileReader.onloadend = function(e) {
                                if (settings.onClientLoadEnd) {
                                    settings.onClientLoadEnd(e, file);
                                }
                            };
                            fileReader.onloadstart = function(e) {
                                if (settings.onClientLoadStart) {
                                    settings.onClientLoadStart(e, file);
                                }
                            };
                            fileReader.onprogress = function(e) {
                                if (settings.onClientProgress) {
                                    settings.onClientProgress(e, file);
                                }
                            };
                            fileReader.readAsDataURL(file);

                            var xmlHttpRequest = new XMLHttpRequest();
                            xmlHttpRequest.upload.onabort = function(e) {
                                if (settings.onServerAbort) {
                                    settings.onServerAbort(e, file);
                                }
                            };
                            xmlHttpRequest.upload.onerror = function(e) {
                                if (settings.onServerError) {
                                    settings.onServerError(e, file);
                                }
                            };
                            xmlHttpRequest.upload.onload = function(e) {
                                if (settings.onServerLoad) {
                                    settings.onServerLoad(e, file);
                                }
                            };
                            xmlHttpRequest.upload.onloadstart = function(e) {
                                if (settings.onServerLoadStart) {
                                    settings.onServerLoadStart(e, file);
                                }
                            };
                            xmlHttpRequest.upload.onprogress = function(e) {
                                if (settings.onServerProgress) {
                                    settings.onServerProgress(e, file);
                                }
                            };
                            xmlHttpRequest.onreadystatechange = function(e) {
                                if (settings.onServerReadyStateChange) {
                                    settings.onServerReadyStateChange(e, file, xmlHttpRequest.readyState);
                                }
                                if (settings.onSuccess && xmlHttpRequest.readyState == 4 && xmlHttpRequest.status == 200) {
                                    settings.onSuccess(e, file, xmlHttpRequest.responseText);
                                }
                            };
                            xmlHttpRequest.open("POST", settings.postUrl, true);

                            if (file.getAsBinary) { // Firefox

                                var data = dashes + boundary + crlf +
                                    "Content-Disposition: form-data;" +
                                    "name=\"" + settings.name + "\";" +
                                    "filename=\"" + unescape(encodeURIComponent(file.name)) + "\"" + crlf +
                                    "Content-Type: application/octet-stream" + crlf + crlf +
                                    file.getAsBinary() + crlf +
                                    dashes + boundary + dashes;

                                xmlHttpRequest.setRequestHeader("Content-Type", "multipart/form-data;boundary=" + boundary);
                                xmlHttpRequest.sendAsBinary(data);

                            } else if (window.FormData) { // Chrome

                                var formData = new FormData();
                                formData.append(settings.name, file);

                                xmlHttpRequest.send(formData);

                            }
                        }

                    };

                })(jQuery);

                (function($) {

                    var methods = {

                        init: function(options) {

                            return this.each(function() {

                                // Create a reference to the jQuery DOM object
                                var $this = $(this);
                                $this.data('uploadifive', {
                                    inputs: {}, // The object that contains all the file inputs
                                    inputCount: 0, // The total number of file inputs created
                                    fileID: 0,
                                    queue: {
                                        count: 0, // Total number of files in the queue
                                        selected: 0, // Number of files selected in the last select operation
                                        replaced: 0, // Number of files replaced in the last select operation
                                        errors: 0, // Number of files that returned an error in the last select operation
                                        queued: 0, // Number of files added to the queue in the last select operation
                                        cancelled: 0 // Total number of files that have been cancelled or removed from the queue
                                    },
                                    uploads: {
                                        current: 0, // Number of files currently being uploaded
                                        attempts: 0, // Number of file uploads attempted in the last upload operation
                                        successful: 0, // Number of files successfully uploaded in the last upload operation
                                        errors: 0, // Number of files returning errors in the last upload operation
                                        count: 0 // Total number of files uploaded successfully
                                    }
                                });
                                var $data = $this.data('uploadifive');

                                // Set the default options
                                var settings = $data.settings = $.extend({
                                    'auto': true, // Automatically upload a file when it's added to the queue
                                    'buttonClass': false, // A class to add to the UploadiFive button
                                    'buttonText': 'Select Files', // The text that appears on the UploadiFive button
                                    'checkScript': false, // Path to the script that checks for existing file names 
                                    'dnd': true, // Allow drag and drop into the queue
                                    'dropTarget': false, // Selector for the drop target
                                    'fileObjName': 'Filedata', // The name of the file object to use in your server-side script
                                    'fileSizeLimit': 0, // Maximum allowed size of files to upload
                                    'fileType': false, // Extension of files allowed (.zip,.rar,.7z,.pdf,...ETC.), separate with a comma character ,
                                    'formData': {}, // Additional data to send to the upload script
                                    'height': 30, // The height of the button
                                    'itemTemplate': false, // The HTML markup for the item in the queue
                                    'method': 'post', // The method to use when submitting the upload
                                    'multi': true, // Set to true to allow multiple file selections
                                    'overrideEvents': [], // An array of events to override
                                    'queueID': false, // The ID of the file queue
                                    'queueSizeLimit': 0, // The maximum number of files that can be in the queue
                                    'removeCompleted': false, // Set to true to remove files that have completed uploading
                                    'simUploadLimit': 0, // The maximum number of files to upload at once
                                    'truncateLength': 0, // The length to truncate the file names to
                                    'uploadLimit': 0, // The maximum number of files you can upload
                                    'uploadScript': 'uploadifive.php', // The path to the upload script
                                    'width': 100 // The width of the button

                                    /*
                                    // Events
                                    'onAddQueueItem'   : function(file) {},                        // Triggered for each file that is added to the queue
                                    'onCancel'         : function(file) {},                        // Triggered when a file is cancelled or removed from the queue
                                    'onCheck'          : function(file, exists) {},                // Triggered when the server is checked for an existing file
                                    'onClearQueue'     : function(queue) {},                       // Triggered during the clearQueue function
                                    'onDestroy'        : function() {}                             // Triggered during the destroy function
                                    'onDrop'           : function(files, numberOfFilesDropped) {}, // Triggered when files are dropped into the file queue
                                    'onError'          : function(file, fileType, data) {},        // Triggered when an error occurs
                                    'onFallback'       : function() {},                            // Triggered if the HTML5 File API is not supported by the browser
                                    'onInit'           : function() {},                            // Triggered when UploadiFive if initialized
                                    'onQueueComplete'  : function() {},                            // Triggered once when an upload queue is done
                                    'onProgress'       : function(file, event) {},                 // Triggered during each progress update of an upload
                                    'onSelect'         : function() {},                            // Triggered once when files are selected from a dialog box
                                    'onUpload'         : function(file) {},                        // Triggered when an upload queue is started
                                    'onUploadComplete' : function(file, data) {},                  // Triggered when a file is successfully uploaded
                                    'onUploadFile'     : function(file) {},                        // Triggered for each file being uploaded
                                    */
                                }, options);

                                // Create an array of file types
                                var file_types;
                                if (settings.fileType) {
                                    file_types = settings.fileType.split(',');
                                }

                                // Calculate the file size limit
                                if (isNaN(settings.fileSizeLimit)) {
                                    var fileSizeLimitBytes = parseInt(settings.fileSizeLimit) * 1.024;
                                    if (settings.fileSizeLimit.indexOf('KB') > -1) {
                                        settings.fileSizeLimit = fileSizeLimitBytes * 1000;
                                    } else if (settings.fileSizeLimit.indexOf('MB') > -1) {
                                        settings.fileSizeLimit = fileSizeLimitBytes * 1000000;
                                    } else if (settings.fileSizeLimit.indexOf('GB') > -1) {
                                        settings.fileSizeLimit = fileSizeLimitBytes * 1000000000;
                                    }
                                } else {
                                    settings.fileSizeLimit = settings.fileSizeLimit * 1024;
                                }

                                // Create a template for a file input
                                $data.inputTemplate = $('<input type="file">')
                                    .css({
                                        'font-size': settings.height + 'px',
                                        'opacity': 0,
                                        'position': 'absolute',
                                        'right': '-3px',
                                        'top': '-3px',
                                        'z-index': 999
                                    });

                                // Create a new input
                                $data.createInput = function() {

                                    // Create a clone of the file input
                                    var input = $data.inputTemplate.clone();
                                    // Create a unique name for the input item
                                    var inputName = input.name = 'input' + $data.inputCount++;
                                    // Set the multiple attribute
                                    if (settings.multi) {
                                        input.attr('multiple', true);
                                    }
                                    // Set the accept attribute on the input
                                    if (settings.fileType) {
                                        input.attr('accept', settings.fileType);
                                    }
                                    // Set the onchange event for the input
                                    input.bind('change', function() {
                                        $data.queue.selected = 0;
                                        $data.queue.replaced = 0;
                                        $data.queue.errors = 0;
                                        $data.queue.queued = 0;
                                        // Add a queue item to the queue for each file
                                        var limit = this.files.length;
                                        $data.queue.selected = limit;
                                        if (($data.queue.count + limit) > settings.queueSizeLimit && settings.queueSizeLimit !== 0) {
                                            if ($.inArray('onError', settings.overrideEvents) < 0) {
                                                alert('The maximum number of queue items has been reached (' + settings.queueSizeLimit + ').  Please select fewer files.');
                                            }
                                            // Trigger the error event
                                            if (typeof settings.onError === 'function') {
                                                settings.onError.call($this, 'QUEUE_LIMIT_EXCEEDED');
                                            }
                                        } else {
                                            for (var n = 0; n < limit; n++) {
                                                file = this.files[n];
                                                $data.addQueueItem(file);
                                            }
                                            $data.inputs[inputName] = this;
                                            $data.createInput();
                                        }
                                        // Upload the file if auto-uploads are enabled
                                        if (settings.auto) {
                                            methods.upload.call($this);
                                        }
                                        // Trigger the select event
                                        if (typeof settings.onSelect === 'function') {
                                            settings.onSelect.call($this, $data.queue);
                                        }
                                    });
                                    // Hide the existing current item and add the new one
                                    if ($data.currentInput) {
                                        $data.currentInput.hide();
                                    }
                                    $data.button.append(input);
                                    $data.currentInput = input;
                                };

                                // Remove an input
                                $data.destroyInput = function(key) {
                                    $($data.inputs[key]).remove();
                                    delete $data.inputs[key];
                                    $data.inputCount--;
                                };

                                // Drop a file into the queue
                                $data.drop = function(e) {
                                    // Stop FireFox from opening the dropped file(s)
                                    e.preventDefault();
                                    e.stopPropagation();

                                    $data.queue.selected = 0;
                                    $data.queue.replaced = 0;
                                    $data.queue.errors = 0;
                                    $data.queue.queued = 0;

                                    var fileData = e.dataTransfer;

                                    var inputName = fileData.name = 'input' + $data.inputCount++;
                                    // Add a queue item to the queue for each file
                                    var limit = fileData.files.length;
                                    $data.queue.selected = limit;
                                    if (($data.queue.count + limit) > settings.queueSizeLimit && settings.queueSizeLimit !== 0) {
                                        // Check if the queueSizeLimit was reached
                                        if ($.inArray('onError', settings.overrideEvents) < 0) {
                                            alert('The maximum number of queue items has been reached (' + settings.queueSizeLimit + ').  Please select fewer files.');
                                        }
                                        // Trigger the onError event
                                        if (typeof settings.onError === 'function') {
                                            settings.onError.call($this, 'QUEUE_LIMIT_EXCEEDED');
                                        }
                                    } else {
                                        // Add a queue item for each file
                                        for (var n = 0; n < limit; n++) {
                                            file = fileData.files[n];
                                            $data.addQueueItem(file);
                                            // Check the filetype
                                            if (file_types) {
                                                if (file_types.indexOf(file.name.substring(file.name.lastIndexOf('.'))) < 0)
                                                    $data.error('FORBIDDEN_FILE_TYPE', file);
                                            }
                                        }
                                        // Save the data to the inputs object
                                        $data.inputs[inputName] = fileData;
                                    }

                                    // Upload the file if auto-uploads are enabled
                                    if (settings.auto) {
                                        methods.upload.call($this);
                                    }

                                    // Trigger the onDrop event
                                    if (typeof settings.onDrop === 'function') {
                                        settings.onDrop.call($this, fileData.files, fileData.files.length);
                                    }
                                };

                                // Check if a filename exists in the queue
                                $data.fileExistsInQueue = function(file) {
                                    for (var key in $data.inputs) {
                                        input = $data.inputs[key];
                                        limit = input.files.length;
                                        for (var n = 0; n < limit; n++) {
                                            existingFile = input.files[n];
                                            // Check if the filename matches
                                            if (existingFile.name == file.name && !existingFile.complete) {
                                                return true;
                                            }
                                        }
                                    }
                                    return false;
                                };

                                // Remove an existing file in the queue
                                $data.removeExistingFile = function(file) {
                                    for (var key in $data.inputs) {
                                        input = $data.inputs[key];
                                        limit = input.files.length;
                                        for (var n = 0; n < limit; n++) {
                                            existingFile = input.files[n];
                                            // Check if the filename matches
                                            if (existingFile.name == file.name && !existingFile.complete) {
                                                $data.queue.replaced++;
                                                methods.cancel.call($this, existingFile, true);
                                            }
                                        }
                                    }
                                };

                                // Create the file item template
                                if (settings.itemTemplate === false) {
                                    $data.queueItem = $('<div class="uploadifive-queue-item">' +
                                        '<a class="close" href="#">X</a>' +
                                        '<div><span class="filename"></span><span class="fileinfo"></span></div>' +
                                        '<div class="progress">' +
                                        '<div class="progress-bar"></div>' +
                                        '</div>' +
                                        '</div>');
                                } else {
                                    $data.queueItem = $(settings.itemTemplate);
                                }

                                // Add an item to the queue
                                $data.addQueueItem = function(file) {
                                    if ($.inArray('onAddQueueItem', settings.overrideEvents) < 0) {
                                        // Check if the filename already exists in the queue
                                        $data.removeExistingFile(file);
                                        // Create a clone of the queue item template
                                        file.queueItem = $data.queueItem.clone();
                                        // Add an ID to the queue item
                                        file.queueItem.attr('id', settings.id + '-file-' + $data.fileID++);
                                        // Bind the close event to the close button
                                        file.queueItem.find('.close').bind('click', function() {
                                            methods.cancel.call($this, file);
                                            return false;
                                        });
                                        var fileName = file.name;
                                        if (fileName.length > settings.truncateLength && settings.truncateLength !== 0) {
                                            fileName = fileName.substring(0, settings.truncateLength) + '...';
                                        }
                                        file.queueItem.find('.filename').html(fileName);
                                        // Add a reference to the file
                                        file.queueItem.data('file', file);
                                        $data.queueEl.append(file.queueItem);
                                    }
                                    // Trigger the addQueueItem event
                                    if (typeof settings.onAddQueueItem === 'function') {
                                        settings.onAddQueueItem.call($this, file);
                                    }
                                    // Check the filetype
                                    if (file_types) {
                                        if (file_types.indexOf(file.name.substring(file.name.lastIndexOf('.'))) < 0)
                                            $data.error('FORBIDDEN_FILE_TYPE', file);
                                    }
                                    // Check the filesize
                                    if (file.size > settings.fileSizeLimit && settings.fileSizeLimit !== 0) {
                                        $data.error('FILE_SIZE_LIMIT_EXCEEDED', file);
                                    } else {
                                        $data.queue.queued++;
                                        $data.queue.count++;
                                    }
                                };

                                // Remove an item from the queue
                                $data.removeQueueItem = function(file, instant, delay) {
                                    // Set the default delay
                                    if (!delay) delay = 0;
                                    var fadeTime = instant ? 0 : 500;
                                    if (file.queueItem) {
                                        if (file.queueItem.find('.fileinfo').html() != ' - Completed') {
                                            file.queueItem.find('.fileinfo').html(' - Cancelled');
                                        }
                                        file.queueItem.find('.progress-bar').width(0);
                                        file.queueItem.delay(delay).fadeOut(fadeTime, function() {
                                            $(this).remove();
                                        });
                                        delete file.queueItem;
                                        $data.queue.count--;
                                    }
                                };

                                // Count the number of files that need to be uploaded
                                $data.filesToUpload = function() {
                                    var filesToUpload = 0;
                                    for (var key in $data.inputs) {
                                        input = $data.inputs[key];
                                        limit = input.files.length;
                                        for (var n = 0; n < limit; n++) {
                                            file = input.files[n];
                                            if (!file.skip && !file.complete) {
                                                filesToUpload++;
                                            }
                                        }
                                    }
                                    return filesToUpload;
                                };

                                // Check if a file exists
                                $data.checkExists = function(file) {
                                    if ($.inArray('onCheck', settings.overrideEvents) < 0) {
                                        // This request needs to be synchronous
                                        $.ajaxSetup({
                                            'async': false
                                        });
                                        // Send the filename to the check script
                                        var checkData = $.extend(settings.formData, {
                                            filename: file.name
                                        });
                                        $.post(settings.checkScript, checkData, function(fileExists) {
                                            file.exists = parseInt(fileExists);
                                        });
                                        if (file.exists) {
                                            if (!confirm('A file named ' + file.name + ' already exists in the upload folder.\nWould you like to replace it?')) {
                                                // If not replacing the file, cancel the upload
                                                methods.cancel.call($this, file);
                                                return true;
                                            }
                                        }
                                    }
                                    // Trigger the check event
                                    if (typeof settings.onCheck === 'function') {
                                        settings.onCheck.call($this, file, file.exists);
                                    }
                                    return false;
                                };

                                // Upload a single file
                                $data.uploadFile = function(file, uploadAll) {
                                    if (!file.skip && !file.complete && !file.uploading) {
                                        file.uploading = true;
                                        $data.uploads.current++;
                                        $data.uploads.attempted++;

                                        // Create a new AJAX request
                                        xhr = file.xhr = new XMLHttpRequest();

                                        // Start the upload
                                        // Use the faster FormData if it exists
                                        if (typeof FormData === 'function' || typeof FormData === 'object') {

                                            // Create a new FormData object
                                            var formData = new FormData();

                                            // Add the form data
                                            formData.append(settings.fileObjName, file);

                                            // Add the rest of the formData
                                            for (var i in settings.formData) {
                                                formData.append(i, settings.formData[i]);
                                            }

                                            // Open the AJAX call
                                            xhr.open(settings.method, settings.uploadScript, true);

                                            // On progress function
                                            xhr.upload.addEventListener('progress', function(e) {
                                                if (e.lengthComputable) {
                                                    $data.progress(e, file);
                                                }
                                            }, false);

                                            // On complete function
                                            xhr.addEventListener('load', function(e) {
                                                if (this.readyState == 4) {
                                                    file.uploading = false;
                                                    if (this.status == 200) {
                                                        if (file.xhr.responseText !== 'Invalid file type.') {
                                                            $data.uploadComplete(e, file, uploadAll);
                                                        } else {
                                                            $data.error(file.xhr.responseText, file, uploadAll);
                                                        }
                                                    } else if (this.status == 404) {
                                                        $data.error('404_FILE_NOT_FOUND', file, uploadAll);
                                                    } else if (this.status == 403) {
                                                        $data.error('403_FORBIDDEN', file, uploadAll);
                                                    } else {
                                                        $data.error('Unknown Error', file, uploadAll);
                                                    }
                                                }
                                            });

                                            // Send the form data (multipart/form-data)
                                            xhr.send(formData);

                                        } else {

                                            // Send as binary
                                            var reader = new FileReader();
                                            reader.onload = function(e) {

                                                // Set some file builder variables
                                                var boundary = '-------------------------' + (new Date()).getTime(),
                                                    dashes = '--',
                                                    eol = '\r\n',
                                                    binFile = '';

                                                // Build an RFC2388 String 
                                                binFile += dashes + boundary + eol;
                                                // Generate the headers
                                                binFile += 'Content-Disposition: form-data; name="' + settings.fileObjName + '"';
                                                if (file.name) {
                                                    binFile += '; filename="' + file.name + '"';
                                                }
                                                binFile += eol;
                                                binFile += 'Content-Type: application/octet-stream' + eol + eol;
                                                binFile += e.target.result + eol;

                                                for (var key in settings.formData) {
                                                    binFile += dashes + boundary + eol;
                                                    binFile += 'Content-Disposition: form-data; name="' + key + '"' + eol + eol;
                                                    binFile += settings.formData[key] + eol;
                                                }

                                                binFile += dashes + boundary + dashes + eol;

                                                // On progress function
                                                xhr.upload.addEventListener('progress', function(e) {
                                                    $data.progress(e, file);
                                                }, false);

                                                // On complete function
                                                xhr.addEventListener('load', function(e) {
                                                    file.uploading = false;
                                                    var status = this.status;
                                                    if (status == 404) {
                                                        $data.error('404_FILE_NOT_FOUND', file, uploadAll);
                                                    } else {
                                                        if (file.xhr.responseText != 'Invalid file type.') {
                                                            $data.uploadComplete(e, file, uploadAll);
                                                        } else {
                                                            $data.error(file.xhr.responseText, file, uploadAll);
                                                        }
                                                    }
                                                }, false);

                                                // Open the ajax request
                                                var url = settings.uploadScript;
                                                if (settings.method == 'get') {
                                                    var params = $(settings.formData).param();
                                                    url += params;
                                                }
                                                xhr.open(settings.method, settings.uploadScript, true);
                                                xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + boundary);

                                                // Trigger the uploadFile event
                                                if (typeof settings.onUploadFile === 'function') {
                                                    settings.onUploadFile.call($this, file);
                                                }

                                                // Send the file for upload
                                                xhr.sendAsBinary(binFile);
                                            };
                                            reader.readAsBinaryString(file);

                                        }
                                    }
                                };

                                // Update a file upload's progress
                                $data.progress = function(e, file) {
                                    var percent;
                                    if ($.inArray('onProgress', settings.overrideEvents) < 0) {
                                        if (e.lengthComputable) {
                                            percent = Math.round((e.loaded / e.total) * 100);
                                        }
                                        file.queueItem.find('.fileinfo').html(' - ' + percent + '%');
                                        file.queueItem.find('.progress-bar').css('width', percent + '%');
                                    }
                                    // Trigger the progress event
                                    if (typeof settings.onProgress === 'function') {
                                        settings.onProgress.call($this, file, e);
                                    }
                                };

                                // Trigger an error
                                $data.error = function(errorType, file, uploadAll) {
                                    if ($.inArray('onError', settings.overrideEvents) < 0) {
                                        // Get the error message
                                        switch (errorType) {
                                            case '404_FILE_NOT_FOUND':
                                                errorMsg = '404 Error';
                                                break;
                                            case '403_FORBIDDEN':
                                                errorMsg = '403 Forbidden';
                                                break;
                                            case 'FORBIDDEN_FILE_TYPE':
                                                errorMsg = 'Forbidden File Type';
                                                break;
                                            case 'FILE_SIZE_LIMIT_EXCEEDED':
                                                errorMsg = 'File Too Large';
                                                break;
                                            default:
                                                errorMsg = 'Unknown Error';
                                                break;
                                        }

                                        // Add the error class to the queue item
                                        file.queueItem.addClass('error')
                                            // Output the error in the queue item
                                            .find('.fileinfo').html(' - ' + errorMsg);
                                        // Hide the 
                                        file.queueItem.find('.progress').remove();
                                    }
                                    // Trigger the error event
                                    if (typeof settings.onError === 'function') {
                                        settings.onError.call($this, errorType, file);
                                    }
                                    file.skip = true;
                                    if (errorType == '404_FILE_NOT_FOUND') {
                                        $data.uploads.errors++;
                                    } else {
                                        $data.queue.errors++;
                                    }
                                    if (uploadAll) {
                                        methods.upload.call($this, null, true);
                                    }
                                };

                                // Trigger when a single file upload is complete
                                $data.uploadComplete = function(e, file, uploadAll) {
                                    if ($.inArray('onUploadComplete', settings.overrideEvents) < 0) {
                                        file.queueItem.find('.progress-bar').css('width', '100%');
                                        file.queueItem.find('.fileinfo').html(' - Completed');
                                        file.queueItem.find('.progress').slideUp(250);
                                        file.queueItem.addClass('complete');
                                    }
                                    // Trigger the complete event
                                    if (typeof settings.onUploadComplete === 'function') {
                                        settings.onUploadComplete.call($this, file, file.xhr.responseText);
                                    }
                                    if (settings.removeCompleted) {
                                        setTimeout(function() {
                                            methods.cancel.call($this, file);
                                        }, 3000);
                                    }
                                    file.complete = true;
                                    $data.uploads.successful++;
                                    $data.uploads.count++;
                                    $data.uploads.current--;
                                    delete file.xhr;
                                    if (uploadAll) {
                                        methods.upload.call($this, null, true);
                                    }
                                };

                                // Trigger when all the files are done uploading
                                $data.queueComplete = function() {
                                    // Trigger the queueComplete event
                                    if (typeof settings.onQueueComplete === 'function') {
                                        settings.onQueueComplete.call($this, $data.uploads);
                                    }
                                };

                                // ----------------------
                                // Initialize UploadiFive
                                // ----------------------

                                // Check if HTML5 is available
                                if (window.File && window.FileList && window.Blob && (window.FileReader || window.FormData)) {
                                    // Assign an ID to the object
                                    settings.id = 'uploadifive-' + $this.attr('id');

                                    // Wrap the file input in a div with overflow set to hidden
                                    $data.button = $('<div id="' + settings.id + '" class="uploadifive-button">' + settings.buttonText + '</div>');
                                    if (settings.buttonClass) $data.button.addClass(settings.buttonClass);

                                    // Style the button wrapper
                                    $data.button.css({
                                        'height': settings.height,
                                        'line-height': settings.height + 'px',
                                        'overflow': 'hidden',
                                        'position': 'relative',
                                        'text-align': 'center',
                                        'width': settings.width
                                    });

                                    // Insert the button above the file input
                                    $this.before($data.button)
                                        // Add the file input to the button
                                        .appendTo($data.button)
                                        // Modify the styles of the file input
                                        .hide();

                                    // Create a new input
                                    $data.createInput.call($this);

                                    // Create the queue container
                                    if (!settings.queueID) {
                                        settings.queueID = settings.id + '-queue';
                                        $data.queueEl = $('<div id="' + settings.queueID + '" class="uploadifive-queue" />');
                                        $data.button.after($data.queueEl);
                                    } else {
                                        $data.queueEl = $('#' + settings.queueID);
                                    }

                                    // Add drag and drop functionality
                                    if (settings.dnd) {
                                        var $dropTarget = settings.dropTarget ? $(settings.dropTarget) : $data.queueEl.get(0);
                                        $dropTarget.addEventListener('dragleave', function(e) {
                                            // Stop FireFox from opening the dropped file(s)
                                            e.preventDefault();
                                            e.stopPropagation();
                                        }, false);
                                        $dropTarget.addEventListener('dragenter', function(e) {
                                            // Stop FireFox from opening the dropped file(s)
                                            e.preventDefault();
                                            e.stopPropagation();
                                        }, false);
                                        $dropTarget.addEventListener('dragover', function(e) {
                                            // Stop FireFox from opening the dropped file(s)
                                            e.preventDefault();
                                            e.stopPropagation();
                                        }, false);
                                        $dropTarget.addEventListener('drop', $data.drop, false);
                                    }

                                    // Send as binary workaround for Chrome
                                    if (!XMLHttpRequest.prototype.sendAsBinary) {
                                        XMLHttpRequest.prototype.sendAsBinary = function(datastr) {
                                            function byteValue(x) {
                                                return x.charCodeAt(0) & 0xff;
                                            }
                                            var ords = Array.prototype.map.call(datastr, byteValue);
                                            var ui8a = new Uint8Array(ords);
                                            this.send(ui8a.buffer);
                                        };
                                    }

                                    // Trigger the oninit event
                                    if (typeof settings.onInit === 'function') {
                                        settings.onInit.call($this);
                                    }

                                } else {

                                    // Trigger the fallback event
                                    if (typeof settings.onFallback === 'function') {
                                        settings.onFallback.call($this);
                                    }
                                    return false;

                                }

                            });

                        },


                        // Write some data to the console
                        debug: function() {

                            return this.each(function() {

                                console.log($(this).data('uploadifive'));

                            });

                        },

                        // Clear all the items from the queue
                        clearQueue: function() {

                            this.each(function() {

                                var $this = $(this),
                                    $data = $this.data('uploadifive'),
                                    settings = $data.settings;

                                for (var key in $data.inputs) {
                                    input = $data.inputs[key];
                                    limit = input.files.length;
                                    for (i = 0; i < limit; i++) {
                                        file = input.files[i];
                                        methods.cancel.call($this, file);
                                    }
                                }
                                // Trigger the onClearQueue event
                                if (typeof settings.onClearQueue === 'function') {
                                    settings.onClearQueue.call($this, $('#' + $data.settings.queueID));
                                }

                            });

                        },

                        // Cancel a file upload in progress or remove a file from the queue
                        cancel: function(file, fast) {

                            this.each(function() {

                                var $this = $(this),
                                    $data = $this.data('uploadifive'),
                                    settings = $data.settings;

                                // If user passed a queue item ID instead of file...
                                if (typeof file === 'string') {
                                    if (!isNaN(file)) {
                                        fileID = 'uploadifive-' + $(this).attr('id') + '-file-' + file;
                                    }
                                    file = $('#' + fileID).data('file');
                                }

                                file.skip = true;
                                $data.filesCancelled++;
                                if (file.uploading) {
                                    $data.uploads.current--;
                                    file.uploading = false;
                                    file.xhr.abort();
                                    delete file.xhr;
                                    methods.upload.call($this);
                                }
                                if ($.inArray('onCancel', settings.overrideEvents) < 0) {
                                    $data.removeQueueItem(file, fast);
                                }

                                // Trigger the cancel event
                                if (typeof settings.onCancel === 'function') {
                                    settings.onCancel.call($this, file);
                                }

                            });

                        },

                        // Upload the files in the queue
                        upload: function(file, keepVars) {

                            this.each(function() {

                                var $this = $(this),
                                    $data = $this.data('uploadifive'),
                                    settings = $data.settings;

                                if (file) {

                                    $data.uploadFile.call($this, file);

                                } else {

                                    // Check if the upload limit was reached
                                    if (($data.uploads.count + $data.uploads.current) < settings.uploadLimit || settings.uploadLimit === 0) {
                                        if (!keepVars) {
                                            $data.uploads.attempted = 0;
                                            $data.uploads.successsful = 0;
                                            $data.uploads.errors = 0;
                                            var filesToUpload = $data.filesToUpload();
                                            // Trigger the onUpload event
                                            if (typeof settings.onUpload === 'function') {
                                                settings.onUpload.call($this, filesToUpload);
                                            }
                                        }

                                        // Loop through the files
                                        $('#' + settings.queueID).find('.uploadifive-queue-item').not('.error, .complete').each(function() {
                                            _file = $(this).data('file');
                                            // Check if the simUpload limit was reached
                                            if (($data.uploads.current >= settings.simUploadLimit && settings.simUploadLimit !== 0) || ($data.uploads.current >= settings.uploadLimit && settings.uploadLimit !== 0) || ($data.uploads.count >= settings.uploadLimit && settings.uploadLimit !== 0)) {
                                                return false;
                                            }
                                            if (settings.checkScript) {
                                                // Let the loop know that we're already processing this file
                                                _file.checking = true;
                                                skipFile = $data.checkExists(_file);
                                                _file.checking = false;
                                                if (!skipFile) {
                                                    $data.uploadFile(_file, true);
                                                }
                                            } else {
                                                $data.uploadFile(_file, true);
                                            }
                                        });
                                        if ($('#' + settings.queueID).find('.uploadifive-queue-item').not('.error, .complete').size() === 0) {
                                            $data.queueComplete();
                                        }
                                    } else {
                                        if ($data.uploads.current === 0) {
                                            if ($.inArray('onError', settings.overrideEvents) < 0) {
                                                if ($data.filesToUpload() > 0 && settings.uploadLimit !== 0) {
                                                    alert('The maximum upload limit has been reached.');
                                                }
                                            }
                                            // Trigger the onError event
                                            if (typeof settings.onError === 'function') {
                                                settings.onError.call($this, 'UPLOAD_LIMIT_EXCEEDED', $data.filesToUpload());
                                            }
                                        }
                                    }

                                }

                            });

                        },

                        // Destroy an instance of UploadiFive
                        destroy: function() {

                            this.each(function() {

                                var $this = $(this),
                                    $data = $this.data('uploadifive'),
                                    settings = $data.settings;

                                // Clear the queue
                                methods.clearQueue.call($this);
                                // Destroy the queue if it was created
                                if (!settings.queueID) $('#' + settings.queueID).remove();
                                // Remove extra inputs
                                $this.siblings('input').remove();
                                // Show the original file input
                                $this.show()
                                    // Move the file input out of the button
                                    .insertBefore($data.button);
                                // Delete the button
                                $data.button.remove();
                                // Trigger the destroy event
                                if (typeof settings.onDestroy === 'function') {
                                    settings.onDestroy.call($this);
                                }

                            });

                        }

                    };

                    $.fn.uploadifive = function(method) {

                        if (methods[method]) {
                            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
                        } else if (typeof method === 'object' || !method) {
                            return methods.init.apply(this, arguments);
                        } else {
                            $.error('The method ' + method + ' does not exist in $.uploadify');
                        }

                    };

                })(jQuery);
            </script>
            <!-- /////////////////////////            DD-Slick Selector -->
            <script>
                (function(e) {
                    e.fn.ddslick = function(l) {
                        if (c[l]) {
                            return c[l].apply(this, Array.prototype.slice.call(arguments, 1))
                        } else {
                            if (typeof l === "object" || !l) {
                                return c.init.apply(this, arguments)
                            } else {
                                e.error("Method " + l + " does not exists.")
                            }
                        }
                    };
                    var c = {},
                        d = {
                            data: [],
                            keepJSONItemsOnTop: false,
                            width: 260,
                            height: null,
                            background: "#eee",
                            selectText: "",
                            defaultSelectedIndex: null,
                            truncateDescription: true,
                            imagePosition: "left",
                            showSelectedHTML: true,
                            clickOffToClose: true,
                            embedCSS: true,
                            onSelected: function() {}
                        },
                        i = '<div class="dd-select"><input class="dd-selected-value" type="hidden" /><a class="dd-selected"></a><span class="dd-pointer dd-pointer-down"></span></div>',
                        a = '<ul class="dd-options"></ul>',
                        b = '<style id="css-ddslick" type="text/css">.dd-select{ border-radius:2px; border:solid 1px #ccc; position:relative; cursor:pointer;}.dd-desc { color:#aaa; display:block; overflow: hidden; font-weight:normal; line-height: 1.4em; }.dd-selected{ overflow:hidden; display:block; padding:10px; font-weight:bold;}.dd-pointer{ width:0; height:0; position:absolute; right:10px; top:50%; margin-top:-3px;}.dd-pointer-down{ border:solid 5px transparent; border-top:solid 5px #000; }.dd-pointer-up{border:solid 5px transparent !important; border-bottom:solid 5px #000 !important; margin-top:-8px;}.dd-options{ border:solid 1px #ccc; border-top:none; list-style:none; box-shadow:0px 1px 5px #ddd; display:none; position:absolute; z-index:2000; margin:0; padding:0;background:#fff; overflow:auto;}.dd-option{ padding:10px; display:block; border-bottom:solid 1px #ddd; overflow:hidden; text-decoration:none; color:#333; cursor:pointer;-webkit-transition: all 0.25s ease-in-out; -moz-transition: all 0.25s ease-in-out;-o-transition: all 0.25s ease-in-out;-ms-transition: all 0.25s ease-in-out; }.dd-options > li:last-child > .dd-option{ border-bottom:none;}.dd-option:hover{ background:#f3f3f3; color:#000;}.dd-selected-description-truncated { text-overflow: ellipsis; white-space:nowrap; }.dd-option-selected { background:#f6f6f6; }.dd-option-image, .dd-selected-image { vertical-align:middle; float:left; margin-right:5px; max-width:64px;}.dd-image-right { float:right; margin-right:15px; margin-left:5px;}.dd-container{ position:relative;}​ .dd-selected-text { font-weight:bold}​</style>';
                    c.init = function(l) {
                        var l = e.extend({}, d, l);
                        if (e("#css-ddslick").length <= 0 && l.embedCSS) {
                            e(b).appendTo("head")
                        }
                        return this.each(function() {
                            var p = e(this),
                                q = p.data("ddslick");
                            if (!q) {
                                var n = [],
                                    o = l.data;
                                p.find("option").each(function() {
                                    var w = e(this),
                                        v = w.data();
                                    n.push({
                                        text: e.trim(w.text()),
                                        value: w.val(),
                                        selected: w.is(":selected"),
                                        description: v.description,
                                        imageSrc: v.imagesrc
                                    })
                                });
                                if (l.keepJSONItemsOnTop) {
                                    e.merge(l.data, n)
                                } else {
                                    l.data = e.merge(n, l.data)
                                }
                                var m = p,
                                    s = e('<div id="' + p.attr("id") + '"></div>');
                                p.replaceWith(s);
                                p = s;
                                p.addClass("dd-container").append(i).append(a);
                                var n = p.find(".dd-select"),
                                    u = p.find(".dd-options");
                                u.css({
                                    width: l.width
                                });
                                n.css({
                                    width: l.width,
                                    background: l.background
                                });
                                p.css({
                                    width: l.width
                                });
                                if (l.height != null) {
                                    u.css({
                                        height: l.height,
                                        overflow: "auto"
                                    })
                                }
                                e.each(l.data, function(v, w) {
                                    if (w.selected) {
                                        l.defaultSelectedIndex = v
                                    }
                                    u.append('<li><a class="dd-option">' + (w.value ? ' <input class="dd-option-value" type="hidden" value="' + w.value + '" />' : "") + (w.imageSrc ? ' <img class="dd-option-image' + (l.imagePosition == "right" ? " dd-image-right" : "") + '" src="' + w.imageSrc + '" />' : "") + (w.text ? ' <label class="dd-option-text">' + w.text + "</label>" : "") + (w.description ? ' <small class="dd-option-description dd-desc">' + w.description + "</small>" : "") + "</a></li>")
                                });
                                var t = {
                                    settings: l,
                                    original: m,
                                    selectedIndex: -1,
                                    selectedItem: null,
                                    selectedData: null
                                };
                                p.data("ddslick", t);
                                if (l.selectText.length > 0 && l.defaultSelectedIndex == null) {
                                    p.find(".dd-selected").html(l.selectText)
                                } else {
                                    var r = (l.defaultSelectedIndex != null && l.defaultSelectedIndex >= 0 && l.defaultSelectedIndex < l.data.length) ? l.defaultSelectedIndex : 0;
                                    j(p, r)
                                }
                                p.find(".dd-select").on("click.ddslick", function() {
                                    f(p)
                                });
                                p.find(".dd-option").on("click.ddslick", function() {
                                    j(p, e(this).closest("li").index())
                                });
                                if (l.clickOffToClose) {
                                    u.addClass("dd-click-off-close");
                                    p.on("click.ddslick", function(v) {
                                        v.stopPropagation()
                                    });
                                    e("body").on("click", function() {
                                        e(".dd-click-off-close").slideUp(50).siblings(".dd-select").find(".dd-pointer").removeClass("dd-pointer-up")
                                    })
                                }
                            }
                        })
                    };
                    c.select = function(l) {
                        return this.each(function() {
                            if (l.index !== undefined) {
                                j(e(this), l.index)
                            }
                        })
                    };
                    c.open = function() {
                        return this.each(function() {
                            var m = e(this),
                                l = m.data("ddslick");
                            if (l) {
                                f(m)
                            }
                        })
                    };
                    c.close = function() {
                        return this.each(function() {
                            var m = e(this),
                                l = m.data("ddslick");
                            if (l) {
                                k(m)
                            }
                        })
                    };
                    c.destroy = function() {
                        return this.each(function() {
                            var n = e(this),
                                m = n.data("ddslick");
                            if (m) {
                                var l = m.original;
                                n.removeData("ddslick").unbind(".ddslick").replaceWith(l)
                            }
                        })
                    };
                    function j(q, s) {
                        var u = q.data("ddslick");
                        var r = q.find(".dd-selected"),
                            n = r.siblings(".dd-selected-value"),
                            v = q.find(".dd-options"),
                            l = r.siblings(".dd-pointer"),
                            p = q.find(".dd-option").eq(s),
                            m = p.closest("li"),
                            o = u.settings,
                            t = u.settings.data[s];
                        q.find(".dd-option").removeClass("dd-option-selected");
                        p.addClass("dd-option-selected");
                        u.selectedIndex = s;
                        u.selectedItem = m;
                        u.selectedData = t;
                        if (o.showSelectedHTML) {
                            r.html((t.imageSrc ? '<img class="dd-selected-image' + (o.imagePosition == "right" ? " dd-image-right" : "") + '" src="' + t.imageSrc + '" />' : "") + (t.text ? '<label class="dd-selected-text">' + t.text + "</label>" : "") + (t.description ? '<small class="dd-selected-description dd-desc' + (o.truncateDescription ? " dd-selected-description-truncated" : "") + '" >' + t.description + "</small>" : ""))
                        } else {
                            r.html(t.text)
                        }
                        n.val(t.value);
                        u.original.val(t.value);
                        q.data("ddslick", u);
                        k(q);
                        g(q);
                        if (typeof o.onSelected == "function") {
                            o.onSelected.call(this, u)
                        }
                    }
                    function f(p) {
                        var o = p.find(".dd-select"),
                            m = o.siblings(".dd-options"),
                            l = o.find(".dd-pointer"),
                            n = m.is(":visible");
                        e(".dd-click-off-close").not(m).slideUp(50);
                        e(".dd-pointer").removeClass("dd-pointer-up");
                        if (n) {
                            m.slideUp("fast");
                            l.removeClass("dd-pointer-up")
                        } else {
                            m.slideDown("fast");
                            l.addClass("dd-pointer-up")
                        }
                        h(p)
                    }
                    function k(l) {
                        l.find(".dd-options").slideUp(50);
                        l.find(".dd-pointer").removeClass("dd-pointer-up").removeClass("dd-pointer-up")
                    }
                    function g(o) {
                        var n = o.find(".dd-select").css("height");
                        var m = o.find(".dd-selected-description");
                        var l = o.find(".dd-selected-image");
                        if (m.length <= 0 && l.length > 0) {
                            o.find(".dd-selected-text").css("lineHeight", n)
                        }
                    }
                    function h(l) {
                        l.find(".dd-option").each(function() {
                            var p = e(this);
                            var n = p.css("height");
                            var o = p.find(".dd-option-description");
                            var m = l.find(".dd-option-image");
                            if (o.length <= 0 && m.length > 0) {
                                p.find(".dd-option-text").css("lineHeight", n)
                            }
                        })
                    }
                })(jQuery);
                //test for iterating over child elements
            </script>
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->


        </body>

        </html>
<?php
    }

    public function uninstallApp()
    {
        $response = '';
        $hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
        $shop_Domain = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
        $topic_header = $_SERVER['HTTP_X_SHOPIFY_TOPIC'];
        $data = file_get_contents('php://input');
        $utf8 = utf8_encode($data);
        $data_json = json_decode($utf8, true);
        $SHOPIFY_SECRUT_KEY = env('SHOPIFY_SECRUT_KEY', '');
        $verified = $this->verify_webhook($data, $hmac_header, $SHOPIFY_SECRUT_KEY);
        $chkProduct = DB::table('freeShippingapp_')->where('shop_url', $shop_Domain)->first();
        $user = (array) $chkProduct;
        $access_token = $user['access_token'];
        $Active_theme_ID =  $user['active_theme_id'];
        $shop = $shop_Domain;

        if ($verified == true) {
            if ($topic_header == 'app/uninstalled' || $topic_header == 'shop/update') {
                if ($topic_header == 'app/uninstalled') {
                    // $array = array(
                    //     'asset' => array(
                    //         "key" => "snippets/Shipping_bar_snippet.liquid"
                    //     )
                    // );
                    // $Delete_snippet_file = $this->shopify_call($access_token, $this->Get_host_shop($shop) , "/admin/api/2021-10/themes/" . $Active_theme_ID . " /assets.json", $array, "DELETE");
                    // $Delete_snippet_file = json_decode($Delete_snippet_file['response'], JSON_PRETTY_PRINT);

                    // $theme = $this->shopify_call($access_token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes.json", array(), 'GET');
                    // $theme = json_decode($theme['response'], JSON_PRETTY_PRINT);

                    // foreach ($theme as $theme_key => $theme_) {
                    //     foreach ($theme_ as $theme_key_ => $theme_value) {
                    //         if($theme_value['role'] == "main"){
                    //             $Active_theme_ID = $theme_value['id'];
                    //             $Active_theme_NAME = $theme_value['name'];
                    //         }
                    //     }
                    // }
                    // $array = array(
                    //     "asset" => array(
                    //         "key" => "layout/theme.liquid"
                    //     )
                    // );
                    // $assets = $this->shopify_call($access_token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/". $Active_theme_ID ."/assets.json", $array, 'GET');
                    // $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
                    // // echo strpos( htmlentities( $assets['asset']['value'] ) , "{% include 'Shipping_bar_snippet' %}" );
                    // if( strpos( htmlentities( $assets['asset']['value'] ) , "{% include 'Shipping_bar_snippet' %}" ) !== false ){
                    //     $Delete_snippet_tag_from_liquid_file = str_replace("{% include 'Shipping_bar_snippet' %}", '', htmlentities( $assets['asset']['value'] ) );
                    //     $array = array(
                    //         "asset" => array(
                    //             "key" => "layout/theme.liquid",
                    //             "value" => $Delete_snippet_tag_from_liquid_file
                    //         )
                    //     );
                    //     $assets = $this->shopify_call($access_token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/". $Active_theme_ID ."/assets.json", $array, 'PUT');
                    //     $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
                    DB::table('freeShippingapp_')->where('shop_url', $shop_Domain)->delete();
                    $response =  $data_json;
                } else {
                    $response = 'This Request is not from shopify verified merchant...';
                }
            }
        }

        $log = fopen($shop_Domain . "_uninstalled.json", "a") or die("Can not open or create this file.");
        if (file_exists($shop_Domain . "_uninstalled.json")) {
            fputs($log, PHP_EOL . $shop_Domain . " TOKEN ::  " . $access_token . " SHOP ::  " . $shop_Domain . ' is successfully deleted from the database.'  . PHP_EOL . json_encode($response));
        } else {
            fputs($log, json_encode($response));
        }
        fclose($log);
        return "";
    }
    public function createProductHook()
    {
        echo "";
    }
    public function createCartHook()
    {
    }
    public function updateCartHook()
    {
    }

    public function upgrade_Basic()
    {
        # code...
    }
    public function upgrade_Pro()
    {
        # code...
    }

    public function shopify_call($token, $shop, $api_endpoint, $query = array(), $method = 'GET', $request_headers = array())
    {
        // Build URL
        //	$url = "https://" . $shop . ".myshopify.com" . $api_endpoint;
        $url = "https://" . $shop . ".myshopify.com" . $api_endpoint;
        if (!is_null($query) && in_array($method, array('GET',     'DELETE'))) $url = $url . "?" . http_build_query($query);
        // Configure cURL
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, TRUE);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 3);
        // curl_setopt($curl, CURLOPT_SSLVERSION, 3);
        curl_setopt($curl, CURLOPT_USERAGENT, 'My New Shopify App v.1');
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        // Setup headers
        $request_headers[] = "";
        if (!is_null($token)) $request_headers[] = "X-Shopify-Access-Token: " . $token;
        curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);
        if ($method != 'GET' && in_array($method, array('POST', 'PUT'))) {
            if (is_array($query)) $query = http_build_query($query);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $query);
        }
        // Send request to Shopify and capture any errors
        $response = curl_exec($curl);
        $error_number = curl_errno($curl);
        $error_message = curl_error($curl);
        // Close cURL to be nice
        curl_close($curl);
        // Return an error is cURL has a problem
        if ($error_number) {
            return $error_message;
        } else {
            // No error, return Shopify's response by parsing out the body and the headers
            $response = preg_split("/\r\n\r\n|\n\n|\r\r/", $response, 2);
            // Convert headers into an array
            $headers = array();
            $header_data = explode("\n", $response[0]);
            $headers['status'] = $header_data[0]; // Does not contain a key, have to explicitly set
            array_shift($header_data); // Remove status, we've already set it above
            foreach ($header_data as $part) {
                $h = explode(":", $part);
                $headers[trim($h[0])] = trim($h[1]);
            }
            // Return headers and Shopify's response
            return array('headers' => $headers, 'response' => $response[1]);
        }
    }

    public function Get_host_shop($shop)
    {
        $url = parse_url('https://' . $shop);
        $host = explode('.', $url['host']);
        $host_shop = $host[0];
        return $host_shop;
    }
    public function verify_webhook($data, $hmac_header, $SHOPIFY_SECRUT_KEY)
    {
        $calculated_hmac = base64_encode(hash_hmac('sha256', $data, $SHOPIFY_SECRUT_KEY, true));
        return hash_equals($hmac_header, $calculated_hmac);
    }
    function webhooks($access_token, $host_shop, $app_url, $version)
    {
        $array = array(
            "webhook" => array(
                "topic"   => "app/uninstalled",
                "address" => route('uninstalled_'),
                "format"  => "json"
            )
        );
        $this->shopify_call($access_token, $host_shop, "/admin/api/" . $version . "/webhooks.json", $array, 'POST');
        // $Uninstall = json_decode($Uninstall['response'], JSON_PRETTY_PRINT);
        // print_r($Uninstall);

        // $array = array(
        //     "webhook" => array("topic" => "products/create",
        //         "address" =>  route('createProductHook_'),
        //         "format"  => "json"
        //     )
        // );
        // $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');

        // $array = array(
        //     "webhook" => array("topic"   => "carts/create",
        //         "address" =>  route('createCartHook_'),
        //         "format"  => "json"
        //     )
        // );
        // $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');

        // $array = array(
        //     "webhook" => array("topic"   => "carts/update",
        //         "address" =>  route('updateCartHook_'),
        //         "format"  => "json"
        //     )
        // );
        // $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');

        // $array = array(
        //     "webhook" => array("topic"   => "products/update",
        //         "address" =>  route('updateProductHook_'),
        //         "format"  => "json"
        //     )
        // );
        // $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');
    }

    function ScriptTags__callFunctions($token, $shop, $version)
    {

        $host_shop = $this->Get_host_shop($shop);
        $script_tag_count = $this->shopify_call($token, $host_shop, "/admin/api/" . $version . "/script_tags/count.json", array(), 'GET');
        $script_tag_count = json_decode($script_tag_count['response'], JSON_PRETTY_PRINT);
        //  print_r($script_tag);
        $script_tag = $this->shopify_call($token, $host_shop, "/admin/api/" . $version . "/script_tags.json", array(), 'GET');
        $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
        // print_r($script_tag);
        if ($script_tag_count['count'] < 1) {
            $script_array = array(
                'script_tag' => array(
                    'event' => 'onload',
                    'src' => env('APP_URL', '') . '/custom_script.js'
                )
            );
            $script_tag =  $this->shopify_call($token, $host_shop, "/admin/api/" . $version . "/script_tags.json", $script_array, 'POST');
            $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
            $script_tag_id = $script_tag['script_tag']['id'];

            // $statement = $pdo->prepare("UPDATE `manage_discounts` SET `script_tag_id`= '" . $script_tag_id . "'  WHERE `shop_url` = '" . $shop . "' ");
            // $statement->execute();
            $check = DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('script_tag_id' => $script_tag_id)
            );
        } else if ($script_tag_count['count'] == 1) {
            $delete_script_tag =  $this->shopify_call($token, $host_shop, "/admin/api/" . $version . "/script_tags/" . $script_tag['script_tags'][0]['id'] . ".json", array(), 'DELETE');
            $delete_script_tag = json_decode($delete_script_tag['response'], JSON_PRETTY_PRINT);
            $script_array = array(
                'script_tag' => array(
                    'event' => 'onload',
                    'src' => env('APP_URL', '') . '/custom_script.js'
                )
            );
            $script_tag =  $this->shopify_call($token, $host_shop, "/admin/api/" . $version . "/script_tags.json", $script_array, 'POST');
            $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
            $script_tag_id = $script_tag['script_tag']['id'];

            $check = DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('script_tag_id' => $script_tag_id)
            );
        }
    }

    public function putCSS_resources_in_shopify_assets($token, $host_shop, $selected_theme_id ){
        /////////////////////////////////////////////   Put  Assets -- Creating Creating  sale_Timer.CSS file in Store....
        $array = array(
            'asset' => array(
                "key" => "assets/sale_Timer.css",
                "value" => file_get_contents( getcwd(). "/saleTimer_css_file.txt" ),
            )
        );
        $Put_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . " /assets.json", $array, 'PUT');
        $Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
        /////////////////////////////////////////////   Get  Assets
        $Get_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", array('asset' => array("key" => 'layout/theme.liquid')), 'GET');
        $Get_selectedTheme_Assets = json_decode($Get_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
        
        if (strpos($Get_selectedTheme_Assets['asset']['value'], "{{ 'sale_Timer.css'  | asset_url | stylesheet_tag }}") !== false) {
            // echo "sale_Timer.CSS file Found in Store!";
        } else {
            $string_html_data_value = substr_replace(
                $Get_selectedTheme_Assets['asset']['value'],
                "{{ 'sale_Timer.css'  | asset_url | stylesheet_tag }}" . PHP_EOL,
                strpos($Get_selectedTheme_Assets['asset']['value'], '</head>'),
                0
            );
            $assets_sale_TimerCSS_link = array(
                "asset" => array(
                    "key" => "layout/theme.liquid",
                    "value" =>  $string_html_data_value,
                )
            );
            
            $Set_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", $assets_sale_TimerCSS_link, 'PUT');
            $Set_selectedTheme_Assets = json_decode($Set_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
            
            // print_r($Set_selectedTheme_Assets);
            
        }
        /////////////////
    }

    public function putJS_resources_in_shopify_assets($token, $host_shop, $selected_theme_id ){
        /////////////////////////////////////////////   Put  Assets -- Creating Creating  CountDown.JS file in Store....
        $array = array(
            'asset' => array(
                "key" => "assets/saleTimer.js",
                "value" => file_get_contents( getcwd(). "/saleTimer_js_file.txt" ),
            )
        );

        $Put_selectedTheme_Assets = $this-> shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . " /assets.json", $array, 'PUT');
        $Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
        /////////////////////////////////////////////   Get  Assets
        $Get_selectedTheme_Assets = $this-> shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", array('asset' => array("key" => 'layout/theme.liquid')), 'GET');
        $Get_selectedTheme_Assets = json_decode($Get_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
        
        if (strpos($Get_selectedTheme_Assets['asset']['value'], "{{ 'saleTimer.js'  | asset_url | script_tag }}") !== false) {
            // echo "saleTimer.JS file Found in Store!";
        } else {
            $string_html_data_value = substr_replace(
                $Get_selectedTheme_Assets['asset']['value'],
                "{{ 'saleTimer.js'  | asset_url | script_tag }}" . PHP_EOL,
                strpos($Get_selectedTheme_Assets['asset']['value'], '</head>'),
                0
            );

            $assets_countDownJS_link = array(
                "asset" => array(
                    "key" => "layout/theme.liquid",
                    "value" =>  $string_html_data_value,
                )
            );

            // /admin/api/2021-10/themes/828155753/assets.json
            $Set_selectedTheme_Assets = $this-> shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", $assets_countDownJS_link, 'PUT');
            $Set_selectedTheme_Assets = json_decode($Set_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);

            // print_r($Set_selectedTheme_Assets);

        }
        /////////////////
    }
    public function putBootstrap_and_fonts_shopify_assets($token, $host_shop, $selected_theme_id ){
        $Get_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", array('asset' => array("key" => 'layout/theme.liquid')), 'GET');
        $Get_selectedTheme_Assets = json_decode($Get_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);

        if (strpos($Get_selectedTheme_Assets['asset']['value'], '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"><link href="https://fonts.googleapis.com/css?family=Montez|Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette" rel="stylesheet" type="text/css">') !== false) {
            // echo "Word Found!";
            
        } else {
            $string_html_data_value = substr_replace(
                $Get_selectedTheme_Assets['asset']['value'],
                '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"><link href="https://fonts.googleapis.com/css?family=Montez|Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette" rel="stylesheet" type="text/css">',
                strpos($Get_selectedTheme_Assets['asset']['value'], '<meta name="theme-color" content="{{ settings.color_button }}">'),
                0
            );
            $assets_html_data_link = array(
                "asset" => array(
                    "key" => "layout/theme.liquid",
                    "value" =>  $string_html_data_value,
                )
            );
            // /admin/api/2021-10/themes/828155753/assets.json
            $Set_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", $assets_html_data_link, 'PUT');
            $Set_selectedTheme_Assets = json_decode($Set_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
            // print_r($Set_selectedTheme_Assets);
        }
    }
    public function putJS_Bootstrap_and_fonts_shopify_assets($token, $host_shop, $selected_theme_id ){
        $Get_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", array('asset' => array("key" => 'layout/theme.liquid')), 'GET');
        $Get_selectedTheme_Assets = json_decode($Get_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);

        if (strpos($Get_selectedTheme_Assets['asset']['value'], '<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script><link href="https://www.cssscript.com/demo/sticky.css" rel="stylesheet" type="text/css">') !== false) {
            // echo "Word Found!";
            
        } else {
            $string_html_data_value = substr_replace(
                $Get_selectedTheme_Assets['asset']['value'],
                '<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script><link href="https://www.cssscript.com/demo/sticky.css" rel="stylesheet" type="text/css">',
                strpos($Get_selectedTheme_Assets['asset']['value'], '<script>'),
                0
            );
            $assets_html_data_link = array(
                "asset" => array(
                    "key" => "layout/theme.liquid",
                    "value" =>  $string_html_data_value,
                )
            );
            // /admin/api/2021-10/themes/828155753/assets.json
            $Set_selectedTheme_Assets = $this->shopify_call($token, $host_shop, "/admin/api/2021-10/themes/" . $selected_theme_id . "/assets.json", $assets_html_data_link, 'PUT');
            $Set_selectedTheme_Assets = json_decode($Set_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
            // print_r($Set_selectedTheme_Assets);
        }
    }



}
?>

