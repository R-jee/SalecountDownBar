<?php
define('SHOPIFY_APP_SECRET', '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'); // Replace with your SECRET KEY

include_once('../../inc/database.php');
include_once('../../inc/functions.php');


$ngrok_url = "https://promotionking.info"; //  /ShopifyApp/Feed_monsterApp
define('Domain_URL_', $ngrok_url . "/ShopifyApp/Feed_monsterApp");

function verify_webhook($data, $hmac_header)
{
    $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_APP_SECRET, true));
    return hash_equals($hmac_header, $calculated_hmac);
}

$response = '';
$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
$shop_Domain = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
$data = file_get_contents('php://input');
$utf8 = utf8_encode($data);
$data_json = json_decode($utf8, true);


$verified = verify_webhook($data, $hmac_header);
//////////////////////////////////////////////////////////////////////////////////////
$url = parse_url('https://' . $shop_Domain);
$host = explode('.', $url['host']);
$host_shop = $host[0];
$shop = $shop_Domain;
//////////////////////////////////////////////////////////////////////////////////////

if ($verified) {
    $response = $data_json;
    
    $stmt = $pdo->prepare("SELECT * FROM `fmapp_` WHERE shop_url=?  LIMIT 1 ");
    $stmt->execute([$shop]);
    $user = $stmt->fetch();

    //  print_r($user['access_token']);
    $token = $user['access_token'];
    $check_for_run_jsonproduct_request = $user['run_jsonproduct_request'];
    $PRODUCT_ARRAY___ = [];

    $APP__NO_OF_FEED_PRODUCTS = $user['no_of_feed_products'];
    if($APP__NO_OF_FEED_PRODUCTS == "unlimited"){
        $APP__NO_OF_FEED_PRODUCTS = 1000000;
    }

    if ($check_for_run_jsonproduct_request == 1) {
        //  if for `run_jsonproduct_request`  --------------------------

        
        $Currency = '';
        $Store_info = shopify_call($token, $host_shop, "/admin/api/2021-10/shop.json", array(), 'GET');
        $Store_DATA = json_decode( $Store_info['response'], JSON_PRETTY_PRINT );
        foreach ($Store_DATA as $m_key => $Store_DATA_row) {
            $Currency = $Store_DATA_row;
        }
        $Currency =  $Currency['currency'] ;     

        $products = shopify_call($token, $host_shop, "/admin/api/2021-10/products.json", array(), 'GET');
        $products = json_decode($products['response'], JSON_PRETTY_PRINT);
        $product_json = json_encode($products);



        foreach ($products as $m_key => $product) {
            foreach ($product as $key => $row) {

                // array_push($PRODUCT_ARRAY___ , 
                //     array(
                //         "title"=> $row['title'], 
                //         "vendor"=> $row['vendor'], 
                //         "manufacturer"=> $row['vendor'],
                //         "description"=> strip_tags($row['body_html'] , ['<b>','<a>','</a>','<html>','</html>']),
                //     )
                // );

                if( $key < ( $APP__NO_OF_FEED_PRODUCTS - 1 ) ) :
                if ($row['status'] == 'active') {
                    $get_prod_varients = shopify_call($token, $host_shop, "/admin/api/2021-10/products/" . $row['id'] . "/variants.json", array(), 'GET');
                    $get_prod_varients = json_decode($get_prod_varients['response'], JSON_PRETTY_PRINT);

                    foreach ($get_prod_varients as $m_key => $varients) {
                        foreach ($varients as $key => $varient) {
                            // print_r( json_encode ($varient) );
                            // echo "<br><hr>";
                            $varient_sale_price = '';
                            $varient_price = 0;
                            $varient_weight = 0;
                            $varient_availibility = "false";
                            $varient_currency_code = $Currency;


                            //      -------------   finding Slae price & Price
                            if ($varient['compare_at_price'] > 0) {

                                // if(  $varient['compare_at_price']  >  $varient['price']  ){
                                $varient_sale_price = $varient['price'];
                                $varient_price = $varient['compare_at_price'];
                                // }

                            } else {
                                $varient_price =  $varient['price'];
                                $varient_sale_price = '';
                            }
                            //      -------------   finding Weight in kg , g , lb , oz
                            if ($varient['grams'] > 0) {
                                if ($varient['weight_unit']  == 'kg') {
                                    $varient_weight = ($varient['grams']) / 1000;
                                } elseif ($varient['weight_unit']  == 'lb') {
                                    $varient_weight = ($varient['grams']) / (453.5924);
                                } elseif ($varient['weight_unit']  == 'oz') {
                                    $varient_weight = ($varient['grams']) / (28.34953);
                                } elseif ($varient['weight_unit']  == 'g') {
                                    $varient_weight =  $varient['grams'];
                                }
                                $varient_weight = number_format($varient_weight, 2);
                            } else {
                                $varient_weight = 0;
                            }

                            //      -------------   finding product Availibility
                            if ($varient['inventory_quantity'] > 0) {
                                $varient_availibility = "true";
                            } else {
                                $varient_availibility = "false";
                            }
                            //      -------------   finding product currency_code   'USD' 
                            if ($varient['presentment_prices'][0]['price']['currency_code'] != null) {
                                $varient_currency_code = $varient['presentment_prices'][0]['price']['currency_code'];
                            } else {
                                $varient_currency_code = $varient_currency_code;
                            }


                            array_push(
                                $PRODUCT_ARRAY___,
                                array(
                                    "id" => $varient['id'],
                                    "parent_product_id" => $varient['product_id'],
                                    "product_type" => $row['product_type'],
                                    "title" => $row['title'],
                                    "description" => strip_tags($row['body_html'], ['<b>', '<a>', '</a>', '<html>', '</html>']),
                                    "image_src" => $row['image']['src'],
                                    "price" =>  $varient_price,
                                    "inventory_quantity" => $varient['inventory_quantity'],
                                    "quantity" => $varient['inventory_quantity'],
                                    "sale_price" => $varient_sale_price,
                                    "prices_currency_code" => $varient_currency_code,
                                    "size" => $varient['option1'],
                                    "color" => $varient['option2'],
                                    "material" => $varient['option3'],
                                    "grams" =>  $varient['grams'],
                                    "weight" => $varient_weight,
                                    "weight_unit" =>  $varient['weight_unit'],
                                    "sku" => $varient['sku'],
                                    "tags" => $row['tags'],
                                    "handle" => $row['handle'],
                                    "vendor" => $row['vendor'],
                                    "manufacturer" => $row['vendor'],
                                    "status" => $row['status'],
                                    "inventory_management" => $varient['inventory_management'],
                                    "availibility" => $varient_availibility,
                                    "link" => 'http://'. $shop . '/products/' . $row['handle'] . "?variant=" . $varient['id'],
                                    "barcode" => $varient['barcode'],
                                    "condition" => "new",

                                )
                            );
                        }
                    }
                }
                // print_r($get_prod_varients);
                // echo "<br><hr>";
                endif;

            }
        }

        // echo json_encode($PRODUCT_ARRAY___);

        $PRODUCT_JSON___ = json_encode($PRODUCT_ARRAY___);


        //  ---------                                    ----------------------------
        //  ---------     CREATE  JSON  file of PRODUCTS ----------------------------
        //  ---------                                    ----------------------------

        $log_json =  fopen("../../files/" . $host_shop . "_productsJSON.json", "w+") or die("Can not open or create this file.");


        $JSON_FILE_URL = Domain_URL_ . "/files/" . $host_shop . "_productsJSON.json";
        if (file_exists("../../files/" . $host_shop . "_productsJSON.json")) {
            fputs($log_json,  $PRODUCT_JSON___);
        } else {
            fputs($log_json,  $PRODUCT_JSON___);
        }
        fclose($log_json);

        // echo $JSON_FILE_URL;

        $put_jsonFile_in_DB = $pdo->prepare("UPDATE `fmapp_` SET `json_file_url`= '" . $JSON_FILE_URL . "' , `run_jsonproduct_request` = 1  WHERE `shop_url` = '" . $shop . "' ");
        $put_jsonFile_in_DB->execute();

        
        //echo 'Your products are being re-imported. This may take a while to complete!';

    } //  end if for `run_jsonproduct_request`  --------------------------  

    
    
} else {
    $response = 'This Request is not from shopify verified merchant...';
}

$log =  fopen($shop_Domain . "_order_fulfilled.json", "a") or die("Can not open or create this file.");

if (file_exists($shop_Domain . "_order_fulfilled.json")) {
    fputs($log, PHP_EOL . json_encode($response));
} else {
    fputs($log, json_encode($response));
}
fclose($log);
