<?php
define('SHOPIFY_APP_SECRET', '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'); // Replace with your SECRET KEY

include_once('../../inc/database.php');
include_once('../../inc/functions.php');


function verify_webhook($data, $hmac_header)
{
    $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_APP_SECRET, true));
    return hash_equals($hmac_header, $calculated_hmac);
}

$response = '';
$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
$shop_Domain = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
$data = file_get_contents('php://input');
$utf8 = utf8_encode($data);
$data_json = json_decode($utf8, true);


$verified = verify_webhook($data, $hmac_header);
//////////////////////////////////////////////////////////////////////////////////////
$url = parse_url('https://' . $shop_Domain);
$host = explode('.', $url['host']);
$host_shop = $host[0];
$shop = $shop_Domain;
//////////////////////////////////////////////////////////////////////////////////////

if ($verified) {
    $response = $data_json;

    $stmt = $pdo->prepare("SELECT * FROM `fmapp_` WHERE shop_url=?  LIMIT 1 ");
    $stmt->execute([$shop]);
    $user = $stmt->fetch();

    //  print_r($user['access_token']);
    $token = $user['access_token'];

    // $products = shopify_call($token, $host_shop, "/admin/api/2021-10/products.json", array(), 'GET');
    // $products = json_decode($products['response'], JSON_PRETTY_PRINT);
    // // print_r("<pre>");
    // // echo ;
    // // print_r("</pre>");
    // $product_json = json_encode($products, true);
    // // $product_json = serialize($product_json);

    // // print_r("<pre>");
    // // print_r($product_json);
    // // print_r("</pre>");

    // $product_titles = array();
    // $product_ids = array();

    // foreach ($products as $key => $product) {
    //     foreach ($product as $key => $value) {
    //         // print_r($value['title'] . "<br>");
    //         array_push($product_titles, $value['title']);
    //     }
    // }
    // // print_r("<pre>");
    // $product_titles = json_encode($product_titles, true);
    // // $product_titles = serialize($product_titles);
    // // print_r( $product_titles );
    // // print_r("</pre>");
    // // print_r(json_decode($product_titles, true));

    // foreach ($products as $key => $product) {
    //     foreach ($product as $key => $value) {
    //         // print_r($value['id'] . "<br>");
    //         array_push($product_ids, $value['id']);
    //     }
    // }

    // $product_ids = json_encode($product_ids, true);
    // // $product_ids = serialize($product_ids);
    // // print_r($product_ids );

    // $stmt = $pdo->prepare("SELECT * FROM `product_json` WHERE `shop_url`=?  LIMIT 1 ");
    // $stmt->execute([$shop]);
    // $prod_json = $stmt->fetch();

    // // echo $prod_json;

    // if (!empty($prod_json)) {
    //     $sql = "UPDATE `product_json` SET `productjson_file` = '" . $product_json . "',`product_titles` = '" . $product_titles . "', `product_ids` = '" . $product_ids . "' WHERE `shop_url` = '" . $shop . "' ";
    //     $statement = $pdo->prepare($sql);
    //     $statement->execute();
    // } elseif (empty($prod_json)) {
    //     //      UPDATE `product_json` SET `id`=[value-1],`shop_url`=[value-2],`productjson_file`=[value-3],`product_titles`=[value-4],`product_ids`=[value-5],`date`=[value-6] WHERE 1
    //     $sql = "INSERT INTO `product_json` ( `shop_url`, `productjson_file`, `product_titles`, `product_ids`) VALUES ('" . $shop . "' , '"  . $product_json . "' , '" . $product_titles . "' , '" . $product_ids . "')";
    //     $statement = $pdo->prepare($sql);
    //     $statement->execute();
    // }

    
} else {
    $response = 'This Request is not from shopify verified merchant...';
}

$log =  fopen($shop_Domain . "_order_delete.json", "a") or die("Can not open or create this file.");

if (file_exists($shop_Domain . "_order_delete.json")) {
    fputs($log, PHP_EOL . json_encode($response));
} else {
    fputs($log, json_encode($response));
}
fclose($log);
