
var scriptFilename = "custom_script.js"; // don't forget to set the filename
var scriptUrl = (function () {
  if (document.currentScript) {
    // support defer & async (mozilla only)
    return document.currentScript.src;
  } else {
    var ls, s;
    var getSrc = function (ls, attr) {
      var i,
        l = ls.length,
        nf,
        s;
      for (i = 0; i < l; i++) {
        s = null;
        if (ls[i].getAttribute.length !== undefined) {
          s = ls[i].getAttribute(attr, 2);
        }
        if (!s) continue; // tag with no src
        nf = s;
        nf = nf.split("?")[0].split("/").pop(); // get script filename
        if (nf === scriptFilename) {
          return s;
        }
      }
    };
    ls = document.getElementsByTagName("script");
    s = getSrc(ls, "src");
    if (!s) {
      // search reference of script loaded by jQuery.getScript() in meta[name=srcipt][content=url]
      ls = document.getElementsByTagName("meta");
      s = getSrc(ls, "content");
    }
    if (s) return s;
  }
  return "";
})();

var shopPath = scriptUrl; //.substring(0, scriptUrl.lastIndexOf('/'))+"/";
// var App_DomainURL = scriptUrl.split(scriptFilename)[0];
var scriptPath = shopPath.substring(0, scriptUrl.lastIndexOf("/")) + "/";
shopPath = shopPath.split("?");
shopPath = shopPath[1];
shopPath = shopPath.split("=");
shopPath = shopPath[1];

var CHECK_IF_APP_IS_INSTALLED_ON_SHOP = '';
var APP_saleTimer_json_Status = 'false';
var APP_saleTimer_json_DATA = '';

var xhttp = new XMLHttpRequest();

xhttp.open("GET", scriptPath.toString() + "ajax-get-app-installed-check?shop=" + shopPath.toString() +"&get_check=1", true);
// xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + shopPath + "&get_check=1", true);
xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhttp.onreadystatechange = function () {
  if (this.readyState == 4 && this.status == 200) {
    // CHECK_IF_APP_IS_INSTALLED_ON_SHOP = JSON.parse(this.response);
    // console.log(this.response);
    if( JSON.parse(this.response).App_script.toString() == 'true' ){
      CHECK_IF_APP_IS_INSTALLED_ON_SHOP = 'true';
      var xhttp = new XMLHttpRequest();
      xhttp.open("GET", scriptPath + "ajax-get-messages-data-saletimer?shop="+ shopPath +"&get_check="+ JSON.parse(this.response).App_script.toString() , true);
      // xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + shopPath + "&get_check="+app_Isntalled__check , true);
      xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      // xhttp.setRequestHeader("Content-type", "json");
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // console.log( (this.response) );
            APP_saleTimer_json_Status = JSON.parse(this.response).Status.toString();
            APP_saleTimer_json_DATA = JSON.parse(this.response).Data.toString();

            if(APP_saleTimer_json_Status == 'true'){
              var clock;
              $(document).ready(function() {
              var ddd_date = JSON.parse(APP_saleTimer_json_DATA).scheduling_sale_date.toString();
              var ttt_time = JSON.parse(APP_saleTimer_json_DATA).scheduling_sale_time.toString();
              var futureDate = new Date( ddd_date +" "+ttt_time );
              // var futureDate = new Date("21-02-2022 20:00");
              var currentDate = new Date();
              // Calculate the difference in seconds between the future and current date
              var diff = futureDate.getTime() / 1000 - currentDate.getTime() / 1000;
              // Calculate day difference and apply class to .clock for extra digit styling.
              function dayDiff(first, second) {
                return (second - first) / (1000 * 60 * 60 * 24);
              }
              if (dayDiff(currentDate, futureDate) < 100) {
                $('.clock').addClass('twoDayDigits');
              } else {
                $('.clock').addClass('threeDayDigits');
              }
              if (diff < 0) {
                diff = 0;
              }
              clock = $('#sale_preview__countdownbar_timer_id').FlipClock(diff, {
                  clockFace: 'DailyCounter',
                  countdown: true,
                  callbacks: {
                    stop: function() {
                        jQuery('#sale_preview_row_container__id').remove();
                    }
                  }
              });
            });
            
              $('body').prepend(`
              <div class="container" id="sale_preview_row_container__id">
                <div id="snow"></div>               
                  <div class="row sale_preview_row__" id="sale_preview_row__id">
                    <div class="col-sm-12 col-md-auto ">
                        <span class="sale_preview_text_message_first_half" id="sale_preview_text_message_first_half_id">`+ JSON.parse(APP_saleTimer_json_DATA).message_text1 +`</span>
                    </div>
                    <div class="col-sm-12 col-md-auto  sale_preview__countdownbar_timer_div" style="align-items: center;">
                        <div class="sale_preview__countdownbar_timer" id="sale_preview__countdownbar_timer_id"></div>
                    </div>
                    <div class="col-sm-12 col-md-auto sale_preview__countdownbar_sale_btn_div">
                        <span class="sale_preview_text_message_second_half" id="sale_preview_text_message_second_half_id">`+ JSON.parse(APP_saleTimer_json_DATA).message_text2 +`</span>
                        <a class="btn btn-primary btn-sm sale_preview__countdownbar_sale_btn sale_preview__countdownbar_sale_btn_a_" href="`+ JSON.parse(APP_saleTimer_json_DATA).saleButton_link +`">`+ JSON.parse(APP_saleTimer_json_DATA).saleButton_label +`</a>
                    </div>
                  </div>
                </div>
                
                <script>
                  // setTimeout(function(){
                  //   var snow = new Snow({
                  //     id: 'snow',
                  //     // theme: 'default',
                  //     theme: 'colors',
                  //     min_size: 1,
                  //     max_size: 4
                  //   }).start();
                  // }, 3000);

                  

                </script>
                <style>
                  #sale_preview_row_container__id{
                    background-color: `+ JSON.parse(APP_saleTimer_json_DATA).background_color +`;
                    background-image: url("`+ scriptPath +'assets/uploads/'+ JSON.parse(APP_saleTimer_json_DATA).image_file_name +`");
                  }
                  #sale_preview_row_container__id {
                    background-color: #000000;
                    margin: 0px;
                    min-width: 100%;
                    display: inline-flex;
                    background-color: `+ JSON.parse(APP_saleTimer_json_DATA).background_color +`;
                    background-image: url("`+ scriptPath +'assets/uploads/'+ JSON.parse(APP_saleTimer_json_DATA).image_file_name +`");
                    align-content: center;
                    justify-content: center;
                  }
                  #sale_preview_row__id {
                    margin-top: `+ JSON.parse(APP_saleTimer_json_DATA).timer_text_heading_font_size_value +`px;
                    display: inline-flex;
                    justify-content: center;
                    align-items: center;
                    align-content: center;
                  }
                  span#sale_preview_text_message_first_half_id, span#sale_preview_text_message_second_half_id {
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).message_text_color +`;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).message_text_font_size_value + JSON.parse(APP_saleTimer_json_DATA).message_text_font_unit_value +`;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).message_text_font_family_selector +`;
                  }
                  .sale_preview__countdownbar_sale_btn.sale_preview__countdownbar_sale_btn_a_ {
                    margin-bottom: 5px;
                    background: `+ JSON.parse(APP_saleTimer_json_DATA).button_background_color +`;
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border-color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border: 2px;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_value + JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_unit +`;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).button_label_font_family_selector +`;
                  }
                  .sale_preview__countdownbar_sale_btn.sale_preview__countdownbar_sale_btn_a_:hover {
                    margin-bottom: 5px;
                    background: `+ JSON.parse(APP_saleTimer_json_DATA).button_background_color +`;
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border-color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border: 2px;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_value + JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_unit +`;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).button_label_font_family_selector +`;
                  }
                  .down .inn, .up .inn {
                    background: `+ JSON.parse(APP_saleTimer_json_DATA).timer_background_color +` !important;
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).timer_text_color +` !important;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).timer_digit_font_size_value + JSON.parse(APP_saleTimer_json_DATA).timer_digit_font_size_unit  +` !important;
                    white-space: nowrap;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).timer_digit_font_family_selector +`;
                  }
                  span.flip-clock-label {
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).timer_heading_color +`;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).timer_text_heading_font_size_value + JSON.parse(APP_saleTimer_json_DATA).timer_text_heading_font_size_unit  +` !important;
                    left: 0px;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).timer_heading_text_font_family_selector +`;
                    
                  }.flip-clock-dot{ color : `+ JSON.parse(APP_saleTimer_json_DATA).timer_heading_color +`}
                </style>
              `);///   end  html body append 
              
            }
        }
      };
      xhttp.send();
    }
  }
};
xhttp.send();


/*  Snow Fall  JS start   */
var Snow = function (options) {
  document.getElementById(options.id).style.position = "fixed";
  document.getElementById(options.id).style.top = 0;
  document.getElementById(options.id).style.left = 0;
  document.getElementById(options.id).style.right = 0;
  document.getElementById(options.id).style.bottom = 0;
  document.getElementById(options.id).style.zIndex = 1000;
  document.getElementById(options.id).style.pointerEvents = "none";

  //create canvas
  this.canvas = document.createElement("canvas"); //add random number to change canvas id
  this.canvas.width = window.innerWidth;
  this.canvas.height = window.innerHeight;
  document.getElementById(options.id).appendChild(this.canvas);

  //get theme
  var theme = "default"
  if (options.theme == "colors" || options.theme == "blues" || options.theme == "watermelon" || options.theme == "berry" || options.theme == "pastel") {
      theme = options.theme;
  }

  //change size
  var min = 2;
  var max = 7;
  if (!isNaN(options.min_size)) {
      min = options.min_size;
  }
  if (!isNaN(options.max_size)) {
      max = options.max_size;
  }

  //snowflake list
  this.snowflakes = []
  for (let i = 0; i < 250; i++) {
      this.snowflakes[i] = new Snowflake(this.canvas, theme, min, max);
      this.snowflakes[i].show();
  }

  function random(min, max) {
      return Math.random() * (max - min) + min;
  }

  //boolean is snow is true or false
  this.go = false;
  this.snowfall = function () {
      requestAnimationFrame(() => this.snowfall());

      if (this.go) {
          //clear canvas
          const context = this.canvas.getContext('2d');
          context.clearRect(0, 0, this.canvas.width, this.canvas.height);

          //update snowflakes
          for (var i = 0; i < 250; i++) {
              this.snowflakes[i].update();
              this.snowflakes[i].show();

              if (this.snowflakes[i].y > this.canvas.height) {
                  this.snowflakes[i].y = random(-20, -200);
              }
          }
      }
  }

  this.snowfall();

  this.start = function () {
      this.go = true;
  }

  this.stop = function () {
      this.go = false;
  }

  this.toggle = function () {
      console.log(this.go);
      this.go = !this.go;
  }
}
var Snowflake = function (canvas, theme, min, max) {
  //snowflake elements
  this.radius = random(min, max);
  this.x = random(0, canvas.width);
  this.y = random(-20, -800);
  this.Vy = random(1, 2)
  console.log(this.canvas)

  //set default
  this.color = "#FFF"

  //apply theme
  if (theme == "colors") {
    this.color =
      "rgb(" +
      Math.floor(Math.random() * 256) +
      "," +
      Math.floor(Math.random() * 256) +
      "," +
      Math.floor(Math.random() * 256) +
      ")";
  } else if (theme == "blues") {
    this.color =
      "rgb(" +
      0 +
      "," +
      0 +
      "," +
      Math.floor(Math.random() * 256) +
      ")";
  } else if (theme == "watermelon") {
    if (Math.random() < 0.5) {
      this.color =
        "rgb(" +
        random(242, 255) +
        "," +
        random(0, 50) +
        "," +
        random(70, 120) +
        ")";
    } else {
      this.color =
        "rgb(" +
        0 +
        "," +
        Math.floor(Math.random() * 256) +
        "," +
        0 +
        ")";
    }
  } else if (theme == "berry") {
    this.color =
      "rgb(" +
      random(40, 150) +
      "," +
      random(0, 50) +
      "," +
      random(80, 180) +
      ")";
  } else if (theme == "pastel") {
    this.color =
      "hsla(" +
      random(0, 360) +
      "," +
      random(40, 80) +
      "%," +
      random(60, 80) +
      "%)";
  }
  this.canvas = canvas;

  this.show = function () {
    var ctx = this.canvas.getContext("2d");
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);
    ctx.closePath();
    ctx.fillStyle = this.color;
    ctx.fill();
  }

  this.update = function () {
    this.y += this.Vy;
  }

  function random(min, max) {
    return Math.random() * (max - min) + min;
  }
}

// export default Snow;

/*  Snow Fall  JS end   */


function saleCountdown_Banner____() {
  return ''+
  `<div class="row sale_preview_row__" id="sale_preview_row__id">
    <div class="col-sm-12 col-md-auto ">
        <span class="sale_preview_text_message_first_half" id="sale_preview_text_message_first_half_id"></span>
    </div>
    <div class="col-sm-12 col-md-auto  sale_preview__countdownbar_timer_div" style="align-items: center;">
        <div class="sale_preview__countdownbar_timer" id="sale_preview__countdownbar_timer_id"></div>
    </div>
    <div class="col-sm-12 col-md-auto sale_preview__countdownbar_sale_btn_div">
        <span class="sale_preview_text_message_second_half" id="sale_preview_text_message_second_half_id"></span>
        <a class="btn btn-primary btn-sm sale_preview__countdownbar_sale_btn sale_preview__countdownbar_sale_btn_a_" href=""></a>
    </div>
  </div>`
  +'';
}
