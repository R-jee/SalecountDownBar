
var scriptFilename = "custom_script.js"; // don't forget to set the filename
var scriptUrl = (function () {
  if (document.currentScript) {
    // support defer & async (mozilla only)
    return document.currentScript.src;
  } else {
    var ls, s;
    var getSrc = function (ls, attr) {
      var i,
        l = ls.length,
        nf,
        s;
      for (i = 0; i < l; i++) {
        s = null;
        if (ls[i].getAttribute.length !== undefined) {
          s = ls[i].getAttribute(attr, 2);
        }
        if (!s) continue; // tag with no src
        nf = s;
        nf = nf.split("?")[0].split("/").pop(); // get script filename
        if (nf === scriptFilename) {
          return s;
        }
      }
    };
    ls = document.getElementsByTagName("script");
    s = getSrc(ls, "src");
    if (!s) {
      // search reference of script loaded by jQuery.getScript() in meta[name=srcipt][content=url]
      ls = document.getElementsByTagName("meta");
      s = getSrc(ls, "content");
    }
    if (s) return s;
  }
  return "";
})();

var shopPath = scriptUrl; //.substring(0, scriptUrl.lastIndexOf('/'))+"/";
// var App_DomainURL = scriptUrl.split(scriptFilename)[0];
var scriptPath = shopPath.substring(0, scriptUrl.lastIndexOf("/")) + "/";
shopPath = shopPath.split("?");
shopPath = shopPath[1];
shopPath = shopPath.split("=");
shopPath = shopPath[1];

var CHECK_IF_APP_IS_INSTALLED_ON_SHOP = '';
var APP_saleTimer_json_Status = 'false';
var APP_saleTimer_json_DATA = '';

var xhttp = new XMLHttpRequest();

xhttp.open("GET", scriptPath.toString() + "ajax-get-app-installed-check?shop=" + shopPath.toString() +"&get_check=1", true);
// xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + shopPath + "&get_check=1", true);
xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhttp.onreadystatechange = function () {
  if (this.readyState == 4 && this.status == 200) {
    // CHECK_IF_APP_IS_INSTALLED_ON_SHOP = JSON.parse(this.response);
    // console.log(this.response);
    if( JSON.parse(this.response).App_script.toString() == 'true' ){
      CHECK_IF_APP_IS_INSTALLED_ON_SHOP = 'true';
      var xhttp = new XMLHttpRequest();
      xhttp.open("GET", scriptPath + "ajax-get-messages-data-saletimer?shop="+ shopPath +"&get_check="+ JSON.parse(this.response).App_script.toString() , true);
      // xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + shopPath + "&get_check="+app_Isntalled__check , true);
      xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      // xhttp.setRequestHeader("Content-type", "json");
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // console.log( (this.response) );
            APP_saleTimer_json_Status = JSON.parse(this.response).Status.toString();
            APP_saleTimer_json_DATA = JSON.parse(this.response).Data.toString();

            if(APP_saleTimer_json_Status == 'true'){
              var clock;
              $(document).ready(function() {
              var ddd_date = JSON.parse(APP_saleTimer_json_DATA).scheduling_sale_date.toString();
              var ttt_time = JSON.parse(APP_saleTimer_json_DATA).scheduling_sale_time.toString();
              var futureDate = new Date( ddd_date +" "+ttt_time );
              // var futureDate = new Date("21-02-2022 20:00");
              var currentDate = new Date();
              // Calculate the difference in seconds between the future and current date
              var diff = futureDate.getTime() / 1000 - currentDate.getTime() / 1000;
              // Calculate day difference and apply class to .clock for extra digit styling.
              function dayDiff(first, second) {
                return (second - first) / (1000 * 60 * 60 * 24);
              }
              if (dayDiff(currentDate, futureDate) < 100) {
                $('.clock').addClass('twoDayDigits');
              } else {
                $('.clock').addClass('threeDayDigits');
              }
              if (diff < 0) {
                diff = 0;
              }
              clock = $('#sale_preview__countdownbar_timer_id').FlipClock(diff, {
                  clockFace: 'DailyCounter',
                  countdown: true,
                  callbacks: {
                    stop: function() {
                        jQuery('#sale_preview_row_container__id').remove();
                    }
                  }
              });
            });
              
              $('body').prepend(`
                <div class="container" id="sale_preview_row_container__id">
                  <div class="row sale_preview_row__" id="sale_preview_row__id">
                    <div class="col-sm-12 col-md-auto ">
                        <span class="sale_preview_text_message_first_half" id="sale_preview_text_message_first_half_id">`+ JSON.parse(APP_saleTimer_json_DATA).message_text1 +`</span>
                    </div>
                    <div class="col-sm-12 col-md-auto  sale_preview__countdownbar_timer_div" style="align-items: center;">
                        <div class="sale_preview__countdownbar_timer" id="sale_preview__countdownbar_timer_id"></div>
                    </div>
                    <div class="col-sm-12 col-md-auto sale_preview__countdownbar_sale_btn_div">
                        <span class="sale_preview_text_message_second_half" id="sale_preview_text_message_second_half_id">`+ JSON.parse(APP_saleTimer_json_DATA).message_text2 +`</span>
                        <a class="btn btn-primary btn-sm sale_preview__countdownbar_sale_btn sale_preview__countdownbar_sale_btn_a_" href="`+ JSON.parse(APP_saleTimer_json_DATA).saleButton_link +`">`+ JSON.parse(APP_saleTimer_json_DATA).saleButton_label +`</a>
                    </div>
                  </div>
                </div>
                <style>
                  #sale_preview_row_container__id{
                    background-color: `+ JSON.parse(APP_saleTimer_json_DATA).background_color +`;
                    background-image: url("`+ scriptPath +'assets/uploads/'+ JSON.parse(APP_saleTimer_json_DATA).image_file_name +`");
                  }
                  #sale_preview_row_container__id {
                    background-color: #000000;
                    margin: 0px;
                    min-width: 100%;
                    display: inline-flex;
                    background-color: `+ JSON.parse(APP_saleTimer_json_DATA).background_color +`;
                    background-image: url("`+ scriptPath +'assets/uploads/'+ JSON.parse(APP_saleTimer_json_DATA).image_file_name +`");
                    align-content: center;
                    justify-content: center;
                  }
                  #sale_preview_row__id {
                    margin-top: `+ JSON.parse(APP_saleTimer_json_DATA).timer_text_heading_font_size_value +`px;
                    display: inline-flex;
                    justify-content: center;
                    align-items: center;
                    align-content: center;
                  }
                  span#sale_preview_text_message_first_half_id, span#sale_preview_text_message_second_half_id {
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).message_text_color +`;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).message_text_font_size_value + JSON.parse(APP_saleTimer_json_DATA).message_text_font_unit_value +`;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).message_text_font_family_selector +`;
                  }
                  .sale_preview__countdownbar_sale_btn.sale_preview__countdownbar_sale_btn_a_ {
                    margin-bottom: 5px;
                    background: `+ JSON.parse(APP_saleTimer_json_DATA).button_background_color +`;
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border-color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border: 2px;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_value + JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_unit +`;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).button_label_font_family_selector +`;
                  }
                  .sale_preview__countdownbar_sale_btn.sale_preview__countdownbar_sale_btn_a_:hover {
                    margin-bottom: 5px;
                    background: `+ JSON.parse(APP_saleTimer_json_DATA).button_background_color +`;
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border-color: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_color +`;
                    border: 2px;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_value + JSON.parse(APP_saleTimer_json_DATA).button_text_font_size_unit +`;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).button_label_font_family_selector +`;
                  }
                  .down .inn, .up .inn {
                    background: `+ JSON.parse(APP_saleTimer_json_DATA).timer_background_color +` !important;
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).timer_text_color +` !important;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).timer_digit_font_size_value + JSON.parse(APP_saleTimer_json_DATA).timer_digit_font_size_unit  +` !important;
                    white-space: nowrap;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).timer_digit_font_family_selector +`;
                  }
                  span.flip-clock-label {
                    color: `+ JSON.parse(APP_saleTimer_json_DATA).timer_heading_color +`;
                    font-size: `+ JSON.parse(APP_saleTimer_json_DATA).timer_text_heading_font_size_value + JSON.parse(APP_saleTimer_json_DATA).timer_text_heading_font_size_unit  +` !important;
                    left: 0px;
                    font-family: `+ JSON.parse(APP_saleTimer_json_DATA).timer_heading_text_font_family_selector +`;
                    
                  }.flip-clock-dot{ color : `+ JSON.parse(APP_saleTimer_json_DATA).timer_heading_color +`}
                </style>
              `);///   end  html body append 
            }
        }
      };
      xhttp.send();
    }
  }
};
xhttp.send();


function saleCountdown_Banner____() {
  return ''+
  `<div class="row sale_preview_row__" id="sale_preview_row__id">
    <div class="col-sm-12 col-md-auto ">
        <span class="sale_preview_text_message_first_half" id="sale_preview_text_message_first_half_id"></span>
    </div>
    <div class="col-sm-12 col-md-auto  sale_preview__countdownbar_timer_div" style="align-items: center;">
        <div class="sale_preview__countdownbar_timer" id="sale_preview__countdownbar_timer_id"></div>
    </div>
    <div class="col-sm-12 col-md-auto sale_preview__countdownbar_sale_btn_div">
        <span class="sale_preview_text_message_second_half" id="sale_preview_text_message_second_half_id"></span>
        <a class="btn btn-primary btn-sm sale_preview__countdownbar_sale_btn sale_preview__countdownbar_sale_btn_a_" href=""></a>
    </div>
  </div>`
  +'';
}

